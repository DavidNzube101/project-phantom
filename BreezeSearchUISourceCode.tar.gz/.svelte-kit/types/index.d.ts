type DynamicRoutes = {
	
};

type Layouts = {
	"/": undefined;
	"/components": undefined
};

export type RouteId = "/" | "/components";

export type RouteParams<T extends RouteId> = T extends keyof DynamicRoutes ? DynamicRoutes[T] : Record<string, never>;

export type LayoutParams<T extends RouteId> = Layouts[T] | Record<string, never>;

export type Pathname = "/" | "/components";

export type ResolvedPathname = `${"" | `/${string}`}${Pathname}`;

export type Asset = "/favico.png" | "/favicon.png";