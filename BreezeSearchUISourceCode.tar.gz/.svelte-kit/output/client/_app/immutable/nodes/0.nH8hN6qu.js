import"../chunks/Bzak7iHL.js";import{o as t,p,q as e,r as i}from"../chunks/DqfaN5kK.js";function c(a,n){var o=t(),r=p(o);e(r,()=>n.children),i(a,o)}export{c as component};
