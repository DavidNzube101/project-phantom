import { clsx as clsx$1 } from "clsx";
import { X as sanitize_props, Y as rest_props, O as push, Z as fallback, _ as ensure_array_like, $ as spread_attributes, a0 as clsx, a1 as element, a2 as slot, a3 as bind_props, Q as pop, a4 as spread_props, a5 as attr, W as escape_html, a6 as copy_payload, a7 as assign_payload, a8 as maybe_selected, a9 as attr_class, aa as stringify } from "../../chunks/index.js";
import { twMerge } from "tailwind-merge";
import { tv } from "tailwind-variants";
function html(value) {
  var html2 = String(value ?? "");
  var open = "<!---->";
  return open + html2 + "<!---->";
}
/**
 * @license lucide-svelte v0.536.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */
const defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": 2,
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};
function Icon($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "name",
    "color",
    "size",
    "strokeWidth",
    "absoluteStrokeWidth",
    "iconNode"
  ]);
  push();
  let name = fallback($$props["name"], void 0);
  let color = fallback($$props["color"], "currentColor");
  let size = fallback($$props["size"], 24);
  let strokeWidth = fallback($$props["strokeWidth"], 2);
  let absoluteStrokeWidth = fallback($$props["absoluteStrokeWidth"], false);
  let iconNode = fallback($$props["iconNode"], () => [], true);
  const mergeClasses = (...classes) => classes.filter((className, index, array) => {
    return Boolean(className) && array.indexOf(className) === index;
  }).join(" ");
  const each_array = ensure_array_like(iconNode);
  $$payload.out.push(`<svg${spread_attributes(
    {
      ...defaultAttributes,
      ...$$restProps,
      width: size,
      height: size,
      stroke: color,
      "stroke-width": absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
      class: clsx(mergeClasses("lucide-icon", "lucide", name ? `lucide-${name}` : "", $$sanitized_props.class))
    },
    null,
    void 0,
    void 0,
    3
  )}><!--[-->`);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let [tag, attrs] = each_array[$$index];
    element($$payload, tag, () => {
      $$payload.out.push(`${spread_attributes({ ...attrs }, null, void 0, void 0, 3)}`);
    });
  }
  $$payload.out.push(`<!--]--><!---->`);
  slot($$payload, $$props, "default", {});
  $$payload.out.push(`<!----></svg>`);
  bind_props($$props, {
    name,
    color,
    size,
    strokeWidth,
    absoluteStrokeWidth,
    iconNode
  });
  pop();
}
function Arrow_right_left($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "m16 3 4 4-4 4" }],
    ["path", { "d": "M20 7H4" }],
    ["path", { "d": "m8 21-4-4 4-4" }],
    ["path", { "d": "M4 17h16" }]
  ];
  Icon($$payload, spread_props([
    { name: "arrow-right-left" },
    $$sanitized_props,
    {
      /**
       * @component @name ArrowRightLeft
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTYgMyA0IDQtNCA0IiAvPgogIDxwYXRoIGQ9Ik0yMCA3SDQiIC8+CiAgPHBhdGggZD0ibTggMjEtNC00IDQtNCIgLz4KICA8cGF0aCBkPSJNNCAxN2gxNiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/arrow-right-left
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Bot($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M12 8V4H8" }],
    [
      "rect",
      { "width": "16", "height": "12", "x": "4", "y": "8", "rx": "2" }
    ],
    ["path", { "d": "M2 14h2" }],
    ["path", { "d": "M20 14h2" }],
    ["path", { "d": "M15 13v2" }],
    ["path", { "d": "M9 13v2" }]
  ];
  Icon($$payload, spread_props([
    { name: "bot" },
    $$sanitized_props,
    {
      /**
       * @component @name Bot
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgOFY0SDgiIC8+CiAgPHJlY3Qgd2lkdGg9IjE2IiBoZWlnaHQ9IjEyIiB4PSI0IiB5PSI4IiByeD0iMiIgLz4KICA8cGF0aCBkPSJNMiAxNGgyIiAvPgogIDxwYXRoIGQ9Ik0yMCAxNGgyIiAvPgogIDxwYXRoIGQ9Ik0xNSAxM3YyIiAvPgogIDxwYXRoIGQ9Ik05IDEzdjIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/bot
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Brain($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M12 18V5" }],
    [
      "path",
      { "d": "M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4" }
    ],
    [
      "path",
      { "d": "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5" }
    ],
    ["path", { "d": "M17.997 5.125a4 4 0 0 1 2.526 5.77" }],
    ["path", { "d": "M18 18a4 4 0 0 0 2-7.464" }],
    [
      "path",
      { "d": "M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517" }
    ],
    ["path", { "d": "M6 18a4 4 0 0 1-2-7.464" }],
    ["path", { "d": "M6.003 5.125a4 4 0 0 0-2.526 5.77" }]
  ];
  Icon($$payload, spread_props([
    { name: "brain" },
    $$sanitized_props,
    {
      /**
       * @component @name Brain
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMThWNSIgLz4KICA8cGF0aCBkPSJNMTUgMTNhNC4xNyA0LjE3IDAgMCAxLTMtNCA0LjE3IDQuMTcgMCAwIDEtMyA0IiAvPgogIDxwYXRoIGQ9Ik0xNy41OTggNi41QTMgMyAwIDEgMCAxMiA1YTMgMyAwIDEgMC01LjU5OCAxLjUiIC8+CiAgPHBhdGggZD0iTTE3Ljk5NyA1LjEyNWE0IDQgMCAwIDEgMi41MjYgNS43NyIgLz4KICA8cGF0aCBkPSJNMTggMThhNCA0IDAgMCAwIDItNy40NjQiIC8+CiAgPHBhdGggZD0iTTE5Ljk2NyAxNy40ODNBNCA0IDAgMSAxIDEyIDE4YTQgNCAwIDEgMS03Ljk2Ny0uNTE3IiAvPgogIDxwYXRoIGQ9Ik02IDE4YTQgNCAwIDAgMS0yLTcuNDY0IiAvPgogIDxwYXRoIGQ9Ik02LjAwMyA1LjEyNWE0IDQgMCAwIDAtMi41MjYgNS43NyIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/brain
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Chart_line($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M3 3v16a2 2 0 0 0 2 2h16" }],
    ["path", { "d": "m19 9-5 5-4-4-3 3" }]
  ];
  Icon($$payload, spread_props([
    { name: "chart-line" },
    $$sanitized_props,
    {
      /**
       * @component @name ChartLine
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMyAzdjE2YTIgMiAwIDAgMCAyIDJoMTYiIC8+CiAgPHBhdGggZD0ibTE5IDktNSA1LTQtNC0zIDMiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/chart-line
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Chevron_down($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [["path", { "d": "m6 9 6 6 6-6" }]];
  Icon($$payload, spread_props([
    { name: "chevron-down" },
    $$sanitized_props,
    {
      /**
       * @component @name ChevronDown
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtNiA5IDYgNiA2LTYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/chevron-down
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Chevron_left($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [["path", { "d": "m15 18-6-6 6-6" }]];
  Icon($$payload, spread_props([
    { name: "chevron-left" },
    $$sanitized_props,
    {
      /**
       * @component @name ChevronLeft
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTUgMTgtNi02IDYtNiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/chevron-left
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Chevron_right($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [["path", { "d": "m9 18 6-6-6-6" }]];
  Icon($$payload, spread_props([
    { name: "chevron-right" },
    $$sanitized_props,
    {
      /**
       * @component @name ChevronRight
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtOSAxOCA2LTYtNi02IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/chevron-right
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Circle_alert($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "10" }],
    ["line", { "x1": "12", "x2": "12", "y1": "8", "y2": "12" }],
    [
      "line",
      { "x1": "12", "x2": "12.01", "y1": "16", "y2": "16" }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "circle-alert" },
    $$sanitized_props,
    {
      /**
       * @component @name CircleAlert
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KICA8bGluZSB4MT0iMTIiIHgyPSIxMiIgeTE9IjgiIHkyPSIxMiIgLz4KICA8bGluZSB4MT0iMTIiIHgyPSIxMi4wMSIgeTE9IjE2IiB5Mj0iMTYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/circle-alert
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Circle_check_big($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M21.801 10A10 10 0 1 1 17 3.335" }],
    ["path", { "d": "m9 11 3 3L22 4" }]
  ];
  Icon($$payload, spread_props([
    { name: "circle-check-big" },
    $$sanitized_props,
    {
      /**
       * @component @name CircleCheckBig
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjEuODAxIDEwQTEwIDEwIDAgMSAxIDE3IDMuMzM1IiAvPgogIDxwYXRoIGQ9Im05IDExIDMgM0wyMiA0IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/circle-check-big
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Clock($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M12 6v6l4 2" }],
    ["circle", { "cx": "12", "cy": "12", "r": "10" }]
  ];
  Icon($$payload, spread_props([
    { name: "clock" },
    $$sanitized_props,
    {
      /**
       * @component @name Clock
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgNnY2bDQgMiIgLz4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/clock
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Cloud($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      { "d": "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "cloud" },
    $$sanitized_props,
    {
      /**
       * @component @name Cloud
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTcuNSAxOUg5YTcgNyAwIDEgMSA2LjcxLTloMS43OWE0LjUgNC41IDAgMSAxIDAgOVoiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/cloud
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Copy($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "rect",
      {
        "width": "14",
        "height": "14",
        "x": "8",
        "y": "8",
        "rx": "2",
        "ry": "2"
      }
    ],
    [
      "path",
      {
        "d": "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"
      }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "copy" },
    $$sanitized_props,
    {
      /**
       * @component @name Copy
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iMTQiIGhlaWdodD0iMTQiIHg9IjgiIHk9IjgiIHJ4PSIyIiByeT0iMiIgLz4KICA8cGF0aCBkPSJNNCAxNmMtMS4xIDAtMi0uOS0yLTJWNGMwLTEuMS45LTIgMi0yaDEwYzEuMSAwIDIgLjkgMiAyIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/copy
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Dollar_sign($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["line", { "x1": "12", "x2": "12", "y1": "2", "y2": "22" }],
    [
      "path",
      { "d": "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "dollar-sign" },
    $$sanitized_props,
    {
      /**
       * @component @name DollarSign
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8bGluZSB4MT0iMTIiIHgyPSIxMiIgeTE9IjIiIHkyPSIyMiIgLz4KICA8cGF0aCBkPSJNMTcgNUg5LjVhMy41IDMuNSAwIDAgMCAwIDdoNWEzLjUgMy41IDAgMCAxIDAgN0g2IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/dollar-sign
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Download($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M12 15V3" }],
    ["path", { "d": "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }],
    ["path", { "d": "m7 10 5 5 5-5" }]
  ];
  Icon($$payload, spread_props([
    { name: "download" },
    $$sanitized_props,
    {
      /**
       * @component @name Download
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMTVWMyIgLz4KICA8cGF0aCBkPSJNMjEgMTV2NGEyIDIgMCAwIDEtMiAySDVhMiAyIDAgMCAxLTItMnYtNCIgLz4KICA8cGF0aCBkPSJtNyAxMCA1IDUgNS01IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/download
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Droplets($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z"
      }
    ],
    [
      "path",
      {
        "d": "M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97"
      }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "droplets" },
    $$sanitized_props,
    {
      /**
       * @component @name Droplets
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNyAxNi4zYzIuMiAwIDQtMS44MyA0LTQuMDUgMC0xLjE2LS41Ny0yLjI2LTEuNzEtMy4xOVM3LjI5IDYuNzUgNyA1LjNjLS4yOSAxLjQ1LTEuMTQgMi44NC0yLjI5IDMuNzZTMyAxMS4xIDMgMTIuMjVjMCAyLjIyIDEuOCA0LjA1IDQgNC4wNXoiIC8+CiAgPHBhdGggZD0iTTEyLjU2IDYuNkExMC45NyAxMC45NyAwIDAgMCAxNCAzLjAyYy41IDIuNSAyIDQuOSA0IDYuNXMzIDMuNSAzIDUuNWE2Ljk4IDYuOTggMCAwIDEtMTEuOTEgNC45NyIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/droplets
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function External_link($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M15 3h6v6" }],
    ["path", { "d": "M10 14 21 3" }],
    [
      "path",
      {
        "d": "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"
      }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "external-link" },
    $$sanitized_props,
    {
      /**
       * @component @name ExternalLink
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUgM2g2djYiIC8+CiAgPHBhdGggZD0iTTEwIDE0IDIxIDMiIC8+CiAgPHBhdGggZD0iTTE4IDEzdjZhMiAyIDAgMCAxLTIgMkg1YTIgMiAwIDAgMS0yLTJWOGEyIDIgMCAwIDEgMi0yaDYiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/external-link
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Eye($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"
      }
    ],
    ["circle", { "cx": "12", "cy": "12", "r": "3" }]
  ];
  Icon($$payload, spread_props([
    { name: "eye" },
    $$sanitized_props,
    {
      /**
       * @component @name Eye
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMi4wNjIgMTIuMzQ4YTEgMSAwIDAgMSAwLS42OTYgMTAuNzUgMTAuNzUgMCAwIDEgMTkuODc2IDAgMSAxIDAgMCAxIDAgLjY5NiAxMC43NSAxMC43NSAwIDAgMS0xOS44NzYgMCIgLz4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIzIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/eye
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function File_spreadsheet($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"
      }
    ],
    ["path", { "d": "M14 2v4a2 2 0 0 0 2 2h4" }],
    ["path", { "d": "M8 13h2" }],
    ["path", { "d": "M14 13h2" }],
    ["path", { "d": "M8 17h2" }],
    ["path", { "d": "M14 17h2" }]
  ];
  Icon($$payload, spread_props([
    { name: "file-spreadsheet" },
    $$sanitized_props,
    {
      /**
       * @component @name FileSpreadsheet
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUgMkg2YTIgMiAwIDAgMC0yIDJ2MTZhMiAyIDAgMCAwIDIgMmgxMmEyIDIgMCAwIDAgMi0yVjdaIiAvPgogIDxwYXRoIGQ9Ik0xNCAydjRhMiAyIDAgMCAwIDIgMmg0IiAvPgogIDxwYXRoIGQ9Ik04IDEzaDIiIC8+CiAgPHBhdGggZD0iTTE0IDEzaDIiIC8+CiAgPHBhdGggZD0iTTggMTdoMiIgLz4KICA8cGF0aCBkPSJNMTQgMTdoMiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/file-spreadsheet
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function File_text($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"
      }
    ],
    ["path", { "d": "M14 2v4a2 2 0 0 0 2 2h4" }],
    ["path", { "d": "M10 9H8" }],
    ["path", { "d": "M16 13H8" }],
    ["path", { "d": "M16 17H8" }]
  ];
  Icon($$payload, spread_props([
    { name: "file-text" },
    $$sanitized_props,
    {
      /**
       * @component @name FileText
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUgMkg2YTIgMiAwIDAgMC0yIDJ2MTZhMiAyIDAgMCAwIDIgMmgxMmEyIDIgMCAwIDAgMi0yVjdaIiAvPgogIDxwYXRoIGQ9Ik0xNCAydjRhMiAyIDAgMCAwIDIgMmg0IiAvPgogIDxwYXRoIGQ9Ik0xMCA5SDgiIC8+CiAgPHBhdGggZD0iTTE2IDEzSDgiIC8+CiAgPHBhdGggZD0iTTE2IDE3SDgiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/file-text
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Globe($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "10" }],
    [
      "path",
      { "d": "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" }
    ],
    ["path", { "d": "M2 12h20" }]
  ];
  Icon($$payload, spread_props([
    { name: "globe" },
    $$sanitized_props,
    {
      /**
       * @component @name Globe
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KICA8cGF0aCBkPSJNMTIgMmExNC41IDE0LjUgMCAwIDAgMCAyMCAxNC41IDE0LjUgMCAwIDAgMC0yMCIgLz4KICA8cGF0aCBkPSJNMiAxMmgyMCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/globe
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Mic($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M12 19v3" }],
    ["path", { "d": "M19 10v2a7 7 0 0 1-14 0v-2" }],
    [
      "rect",
      { "x": "9", "y": "2", "width": "6", "height": "13", "rx": "3" }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "mic" },
    $$sanitized_props,
    {
      /**
       * @component @name Mic
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgMTl2MyIgLz4KICA8cGF0aCBkPSJNMTkgMTB2MmE3IDcgMCAwIDEtMTQgMHYtMiIgLz4KICA8cmVjdCB4PSI5IiB5PSIyIiB3aWR0aD0iNiIgaGVpZ2h0PSIxMyIgcng9IjMiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/mic
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Refresh_cw($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      { "d": "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" }
    ],
    ["path", { "d": "M21 3v5h-5" }],
    [
      "path",
      { "d": "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" }
    ],
    ["path", { "d": "M8 16H3v5" }]
  ];
  Icon($$payload, spread_props([
    { name: "refresh-cw" },
    $$sanitized_props,
    {
      /**
       * @component @name RefreshCw
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMyAxMmE5IDkgMCAwIDEgOS05IDkuNzUgOS43NSAwIDAgMSA2Ljc0IDIuNzRMMjEgOCIgLz4KICA8cGF0aCBkPSJNMjEgM3Y1aC01IiAvPgogIDxwYXRoIGQ9Ik0yMSAxMmE5IDkgMCAwIDEtOSA5IDkuNzUgOS43NSAwIDAgMS02Ljc0LTIuNzRMMyAxNiIgLz4KICA8cGF0aCBkPSJNOCAxNkgzdjUiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/refresh-cw
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Search($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "m21 21-4.34-4.34" }],
    ["circle", { "cx": "11", "cy": "11", "r": "8" }]
  ];
  Icon($$payload, spread_props([
    { name: "search" },
    $$sanitized_props,
    {
      /**
       * @component @name Search
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMjEgMjEtNC4zNC00LjM0IiAvPgogIDxjaXJjbGUgY3g9IjExIiBjeT0iMTEiIHI9IjgiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/search
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Shield($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"
      }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "shield" },
    $$sanitized_props,
    {
      /**
       * @component @name Shield
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjAgMTNjMCA1LTMuNSA3LjUtNy42NiA4Ljk1YTEgMSAwIDAgMS0uNjctLjAxQzcuNSAyMC41IDQgMTggNCAxM1Y2YTEgMSAwIDAgMSAxLTFjMiAwIDQuNS0xLjIgNi4yNC0yLjcyYTEuMTcgMS4xNyAwIDAgMSAxLjUyIDBDMTQuNTEgMy44MSAxNyA1IDE5IDVhMSAxIDAgMCAxIDEgMXoiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/shield
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Sparkles($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z"
      }
    ],
    ["path", { "d": "M20 2v4" }],
    ["path", { "d": "M22 4h-4" }],
    ["circle", { "cx": "4", "cy": "20", "r": "2" }]
  ];
  Icon($$payload, spread_props([
    { name: "sparkles" },
    $$sanitized_props,
    {
      /**
       * @component @name Sparkles
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTEuMDE3IDIuODE0YTEgMSAwIDAgMSAxLjk2NiAwbDEuMDUxIDUuNTU4YTIgMiAwIDAgMCAxLjU5NCAxLjU5NGw1LjU1OCAxLjA1MWExIDEgMCAwIDEgMCAxLjk2NmwtNS41NTggMS4wNTFhMiAyIDAgMCAwLTEuNTk0IDEuNTk0bC0xLjA1MSA1LjU1OGExIDEgMCAwIDEtMS45NjYgMGwtMS4wNTEtNS41NThhMiAyIDAgMCAwLTEuNTk0LTEuNTk0bC01LjU1OC0xLjA1MWExIDEgMCAwIDEgMC0xLjk2Nmw1LjU1OC0xLjA1MWEyIDIgMCAwIDAgMS41OTQtMS41OTR6IiAvPgogIDxwYXRoIGQ9Ik0yMCAydjQiIC8+CiAgPHBhdGggZD0iTTIyIDRoLTQiIC8+CiAgPGNpcmNsZSBjeD0iNCIgY3k9IjIwIiByPSIyIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/sparkles
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Sun($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "4" }],
    ["path", { "d": "M12 2v2" }],
    ["path", { "d": "M12 20v2" }],
    ["path", { "d": "m4.93 4.93 1.41 1.41" }],
    ["path", { "d": "m17.66 17.66 1.41 1.41" }],
    ["path", { "d": "M2 12h2" }],
    ["path", { "d": "M20 12h2" }],
    ["path", { "d": "m6.34 17.66-1.41 1.41" }],
    ["path", { "d": "m19.07 4.93-1.41 1.41" }]
  ];
  Icon($$payload, spread_props([
    { name: "sun" },
    $$sanitized_props,
    {
      /**
       * @component @name Sun
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSI0IiAvPgogIDxwYXRoIGQ9Ik0xMiAydjIiIC8+CiAgPHBhdGggZD0iTTEyIDIwdjIiIC8+CiAgPHBhdGggZD0ibTQuOTMgNC45MyAxLjQxIDEuNDEiIC8+CiAgPHBhdGggZD0ibTE3LjY2IDE3LjY2IDEuNDEgMS40MSIgLz4KICA8cGF0aCBkPSJNMiAxMmgyIiAvPgogIDxwYXRoIGQ9Ik0yMCAxMmgyIiAvPgogIDxwYXRoIGQ9Im02LjM0IDE3LjY2LTEuNDEgMS40MSIgLz4KICA8cGF0aCBkPSJtMTkuMDcgNC45My0xLjQxIDEuNDEiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/sun
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Test_tube($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M14.5 2v17.5c0 1.4-1.1 2.5-2.5 2.5c-1.4 0-2.5-1.1-2.5-2.5V2"
      }
    ],
    ["path", { "d": "M8.5 2h7" }],
    ["path", { "d": "M14.5 16h-5" }]
  ];
  Icon($$payload, spread_props([
    { name: "test-tube" },
    $$sanitized_props,
    {
      /**
       * @component @name TestTube
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTQuNSAydjE3LjVjMCAxLjQtMS4xIDIuNS0yLjUgMi41Yy0xLjQgMC0yLjUtMS4xLTIuNS0yLjVWMiIgLz4KICA8cGF0aCBkPSJNOC41IDJoNyIgLz4KICA8cGF0aCBkPSJNMTQuNSAxNmgtNSIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/test-tube
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Thermometer($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      { "d": "M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z" }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "thermometer" },
    $$sanitized_props,
    {
      /**
       * @component @name Thermometer
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTQgNHYxMC41NGE0IDQgMCAxIDEtNCAwVjRhMiAyIDAgMCAxIDQgMFoiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/thermometer
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Trending_down($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M16 17h6v-6" }],
    ["path", { "d": "m22 17-8.5-8.5-5 5L2 7" }]
  ];
  Icon($$payload, spread_props([
    { name: "trending-down" },
    $$sanitized_props,
    {
      /**
       * @component @name TrendingDown
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTYgMTdoNnYtNiIgLz4KICA8cGF0aCBkPSJtMjIgMTctOC41LTguNS01IDVMMiA3IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/trending-down
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Trending_up($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M16 7h6v6" }],
    ["path", { "d": "m22 7-8.5 8.5-5-5L2 17" }]
  ];
  Icon($$payload, spread_props([
    { name: "trending-up" },
    $$sanitized_props,
    {
      /**
       * @component @name TrendingUp
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTYgN2g2djYiIC8+CiAgPHBhdGggZD0ibTIyIDctOC41IDguNS01LTVMMiAxNyIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/trending-up
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Wind($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M12.8 19.6A2 2 0 1 0 14 16H2" }],
    ["path", { "d": "M17.5 8a2.5 2.5 0 1 1 2 4H2" }],
    ["path", { "d": "M9.8 4.4A2 2 0 1 1 11 8H2" }]
  ];
  Icon($$payload, spread_props([
    { name: "wind" },
    $$sanitized_props,
    {
      /**
       * @component @name Wind
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIuOCAxOS42QTIgMiAwIDEgMCAxNCAxNkgyIiAvPgogIDxwYXRoIGQ9Ik0xNy41IDhhMi41IDIuNSAwIDEgMSAyIDRIMiIgLz4KICA8cGF0aCBkPSJNOS44IDQuNEEyIDIgMCAxIDEgMTEgOEgyIiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/wind
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function X($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M18 6 6 18" }],
    ["path", { "d": "m6 6 12 12" }]
  ];
  Icon($$payload, spread_props([
    { name: "x" },
    $$sanitized_props,
    {
      /**
       * @component @name X
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTggNiA2IDE4IiAvPgogIDxwYXRoIGQ9Im02IDYgMTIgMTIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/x
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Zap($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.536.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"
      }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "zap" },
    $$sanitized_props,
    {
      /**
       * @component @name Zap
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNCAxNGExIDEgMCAwIDEtLjc4LTEuNjNsOS45LTEwLjJhLjUuNSAwIDAgMSAuODYuNDZsLTEuOTIgNi4wMkExIDEgMCAwIDAgMTMgMTBoN2ExIDEgMCAwIDEgLjc4IDEuNjNsLTkuOSAxMC4yYS41LjUgMCAwIDEtLjg2LS40NmwxLjkyLTYuMDJBMSAxIDAgMCAwIDExIDE0eiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/zap
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function cn(...inputs) {
  return twMerge(clsx$1(inputs));
}
const buttonVariants = tv({
  base: "focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive inline-flex shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium outline-none transition-all focus-visible:ring-[3px] disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&_svg:not([class*='size-'])]:size-4 [&_svg]:pointer-events-none [&_svg]:shrink-0",
  variants: {
    variant: {
      default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",
      destructive: "bg-destructive shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60 text-white",
      outline: "bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50 border",
      secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
      ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
      link: "text-primary underline-offset-4 hover:underline"
    },
    size: {
      default: "h-9 px-4 py-2 has-[>svg]:px-3",
      sm: "h-8 gap-1.5 rounded-md px-3 has-[>svg]:px-2.5",
      lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
      icon: "size-9"
    }
  },
  defaultVariants: { variant: "default", size: "default" }
});
function Button($$payload, $$props) {
  push();
  let {
    class: className,
    variant = "default",
    size = "default",
    ref = null,
    href = void 0,
    type = "button",
    disabled,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  if (href) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<a${spread_attributes(
      {
        "data-slot": "button",
        class: clsx(cn(buttonVariants({ variant, size }), className)),
        href: disabled ? void 0 : href,
        "aria-disabled": disabled,
        role: disabled ? "link" : void 0,
        tabindex: disabled ? -1 : void 0,
        ...restProps
      }
    )}>`);
    children?.($$payload);
    $$payload.out.push(`<!----></a>`);
  } else {
    $$payload.out.push("<!--[!-->");
    $$payload.out.push(`<button${spread_attributes(
      {
        "data-slot": "button",
        class: clsx(cn(buttonVariants({ variant, size }), className)),
        type,
        disabled,
        ...restProps
      }
    )}>`);
    children?.($$payload);
    $$payload.out.push(`<!----></button>`);
  }
  $$payload.out.push(`<!--]-->`);
  bind_props($$props, { ref });
  pop();
}
function Input($$payload, $$props) {
  push();
  let {
    ref = null,
    value = void 0,
    type,
    files = void 0,
    class: className,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  if (type === "file") {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<input${spread_attributes(
      {
        "data-slot": "input",
        class: clsx(cn("selection:bg-primary dark:bg-input/30 selection:text-primary-foreground border-input ring-offset-background placeholder:text-muted-foreground shadow-xs flex h-9 w-full min-w-0 rounded-md border bg-transparent px-3 pt-1.5 text-sm font-medium outline-none transition-[color,box-shadow] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]", "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className)),
        type: "file",
        ...restProps
      }
    )}/>`);
  } else {
    $$payload.out.push("<!--[!-->");
    $$payload.out.push(`<input${spread_attributes(
      {
        "data-slot": "input",
        class: clsx(cn("border-input bg-background selection:bg-primary dark:bg-input/30 selection:text-primary-foreground ring-offset-background placeholder:text-muted-foreground shadow-xs flex h-9 w-full min-w-0 rounded-md border px-3 py-1 text-base outline-none transition-[color,box-shadow] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]", "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className)),
        type,
        value,
        ...restProps
      }
    )}/>`);
  }
  $$payload.out.push(`<!--]-->`);
  bind_props($$props, { ref, value, files });
  pop();
}
function Card($$payload, $$props) {
  push();
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out.push(`<div${spread_attributes(
    {
      "data-slot": "card",
      class: clsx(cn("bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm", className)),
      ...restProps
    }
  )}>`);
  children?.($$payload);
  $$payload.out.push(`<!----></div>`);
  bind_props($$props, { ref });
  pop();
}
function Card_content($$payload, $$props) {
  push();
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out.push(`<div${spread_attributes(
    {
      "data-slot": "card-content",
      class: clsx(cn("px-6", className)),
      ...restProps
    }
  )}>`);
  children?.($$payload);
  $$payload.out.push(`<!----></div>`);
  bind_props($$props, { ref });
  pop();
}
const badgeVariants = tv({
  base: "focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive inline-flex w-fit shrink-0 items-center justify-center gap-1 overflow-hidden whitespace-nowrap rounded-md border px-2 py-0.5 text-xs font-medium transition-[color,box-shadow] focus-visible:ring-[3px] [&>svg]:pointer-events-none [&>svg]:size-3",
  variants: {
    variant: {
      default: "bg-primary text-primary-foreground [a&]:hover:bg-primary/90 border-transparent",
      secondary: "bg-secondary text-secondary-foreground [a&]:hover:bg-secondary/90 border-transparent",
      destructive: "bg-destructive [a&]:hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/70 border-transparent text-white",
      outline: "text-foreground [a&]:hover:bg-accent [a&]:hover:text-accent-foreground"
    }
  },
  defaultVariants: { variant: "default" }
});
function Badge($$payload, $$props) {
  push();
  let {
    ref = null,
    href,
    class: className,
    variant = "default",
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  element(
    $$payload,
    href ? "a" : "span",
    () => {
      $$payload.out.push(`${spread_attributes(
        {
          "data-slot": "badge",
          href,
          class: clsx(cn(badgeVariants({ variant }), className)),
          ...restProps
        }
      )}`);
    },
    () => {
      children?.($$payload);
      $$payload.out.push(`<!---->`);
    }
  );
  bind_props($$props, { ref });
  pop();
}
function SiteLogo($$payload, $$props) {
  let { domain, hasLogo } = $$props;
  const logoUrls = {
    "privacy-guide.org": "/placeholder.svg?height=32&width=32",
    "digital-rights.org": "/placeholder.svg?height=32&width=32",
    "secure-chat.info": "/placeholder.svg?height=32&width=32"
  };
  function getLogoUrl(domain2) {
    return logoUrls[domain2] || null;
  }
  $$payload.out.push(`<div class="flex-shrink-0">`);
  if (hasLogo && getLogoUrl(domain)) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="relative h-8 w-8"><img${attr("src", getLogoUrl(domain) || "/placeholder.svg")}${attr("alt", `${domain} logo`)} class="h-8 w-8 rounded-lg object-cover" onerror="this.__e=event"/> <div class="hidden h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-purple-700 text-white font-semibold text-sm">B</div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
    $$payload.out.push(`<div class="h-8 w-8 flex items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-purple-700 text-white font-semibold text-sm">B</div>`);
  }
  $$payload.out.push(`<!--]--></div>`);
}
function AISummary($$payload, $$props) {
  push();
  let { searchQuery } = $$props;
  let isRevealed = false;
  let showModal = false;
  let isGenerating = false;
  const aiSummary = `Based on your search for "${searchQuery}", here's what I found:

**Key Insights:**
• Privacy tools have evolved significantly in 2024, with new focus on zero-knowledge architectures
• End-to-end encryption is becoming standard across messaging platforms
• Open-source alternatives are gaining mainstream adoption due to privacy concerns
• New regulations like GDPR 2.0 are pushing companies toward privacy-by-design

**Top Recommendations:**
1. **Signal** - Most secure messaging app with perfect forward secrecy
2. **Tor Browser** - Enhanced privacy browsing with improved speed
3. **ProtonMail** - Zero-access encryption for email communications
4. **Brave Browser** - Built-in ad blocking and privacy protection

**Recent Developments:**
The privacy landscape has shifted dramatically with major tech companies implementing new data collection policies. Users are increasingly seeking alternatives that prioritize privacy without sacrificing functionality.

**Privacy Score:** 9.2/10 - These tools offer excellent privacy protection with minimal data collection.`;
  function revealSummary() {
    isRevealed = true;
    isGenerating = true;
    setTimeout(
      () => {
        isGenerating = false;
        showModal = true;
      },
      1500
    );
  }
  function closeModal() {
    showModal = false;
  }
  Card($$payload, {
    class: "border-purple-700/30 bg-gradient-to-r from-blue-900/20 to-purple-900/20 backdrop-blur-sm shadow-sm relative overflow-hidden",
    children: ($$payload2) => {
      Card_content($$payload2, {
        class: "p-6",
        children: ($$payload3) => {
          $$payload3.out.push(`<div class="flex items-start gap-4"><div class="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex-shrink-0">`);
          Bot($$payload3, { class: "h-5 w-5 text-white" });
          $$payload3.out.push(`<!----></div> <div class="flex-1"><div class="flex items-center gap-2 mb-3"><h3 class="text-lg font-semibold text-white">AI Summary</h3> `);
          Badge($$payload3, {
            variant: "secondary",
            class: "bg-blue-500/20 text-blue-400 border-blue-500/30",
            children: ($$payload4) => {
              Sparkles($$payload4, { class: "h-3 w-3 mr-1" });
              $$payload4.out.push(`<!----> Powered by AI`);
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----></div> `);
          if (!isRevealed) {
            $$payload3.out.push("<!--[-->");
            $$payload3.out.push(`<div class="relative"><div class="blur-sm select-none pointer-events-none text-purple-200 leading-relaxed mb-4">Based on your search for "${escape_html(searchQuery)}", here are the key insights about privacy tools and digital security. This comprehensive analysis covers the latest developments in privacy technology, recommended tools, and important considerations for protecting your digital footprint...</div> <div class="absolute inset-0 bg-gradient-to-r from-transparent via-purple-900/80 to-transparent"></div></div> `);
            Button($$payload3, {
              onclick: revealSummary,
              class: "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white",
              children: ($$payload4) => {
                Eye($$payload4, { class: "h-4 w-4 mr-2" });
                $$payload4.out.push(`<!----> Reveal AI Summary`);
              },
              $$slots: { default: true }
            });
            $$payload3.out.push(`<!---->`);
          } else {
            $$payload3.out.push("<!--[!-->");
            if (isGenerating) {
              $$payload3.out.push("<!--[-->");
              $$payload3.out.push(`<div class="flex items-center gap-3 py-8"><div class="h-6 w-6 animate-spin rounded-full border-2 border-purple-500/30 border-t-purple-500"></div> <p class="text-purple-200">Generating AI summary...</p></div>`);
            } else {
              $$payload3.out.push("<!--[!-->");
              $$payload3.out.push(`<div class="text-purple-200 leading-relaxed mb-4"><p class="line-clamp-3 svelte-1o294ye">Based on your search for "${escape_html(searchQuery)}", here are the key insights about privacy tools and digital security. This comprehensive analysis covers the latest developments...</p></div> `);
              Button($$payload3, {
                onclick: () => showModal = true,
                variant: "outline",
                class: "border-purple-500 text-purple-300 hover:bg-purple-800/30 hover:text-white",
                children: ($$payload4) => {
                  $$payload4.out.push(`<!---->View Full Summary`);
                },
                $$slots: { default: true }
              });
              $$payload3.out.push(`<!---->`);
            }
            $$payload3.out.push(`<!--]-->`);
          }
          $$payload3.out.push(`<!--]--></div></div>`);
        },
        $$slots: { default: true }
      });
    },
    $$slots: { default: true }
  });
  $$payload.out.push(`<!----> `);
  if (showModal) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"><div class="bg-purple-900/90 backdrop-blur-sm rounded-2xl shadow-2xl max-w-4xl w-full max-h-[80vh] overflow-hidden border border-purple-700/50"><div class="flex items-center justify-between p-6 border-b border-purple-700/50"><div class="flex items-center gap-3"><div class="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-purple-500">`);
    Bot($$payload, { class: "h-4 w-4 text-white" });
    $$payload.out.push(`<!----></div> <h2 class="text-xl font-semibold text-white">AI Summary</h2> `);
    Badge($$payload, {
      variant: "secondary",
      class: "bg-blue-500/20 text-blue-400 border-blue-500/30",
      children: ($$payload2) => {
        Sparkles($$payload2, { class: "h-3 w-3 mr-1" });
        $$payload2.out.push(`<!----> Generated`);
      },
      $$slots: { default: true }
    });
    $$payload.out.push(`<!----></div> `);
    Button($$payload, {
      variant: "ghost",
      size: "sm",
      onclick: closeModal,
      class: "text-purple-400 hover:text-white hover:bg-purple-800/50",
      children: ($$payload2) => {
        X($$payload2, { class: "h-5 w-5" });
      },
      $$slots: { default: true }
    });
    $$payload.out.push(`<!----></div> <div class="p-6 overflow-y-auto max-h-[60vh]"><div class="prose prose-invert max-w-none text-purple-200">${html(aiSummary.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>').replace(/\n/g, "<br>").replace(/•/g, "&bull;"))}</div></div> <div class="flex items-center justify-between p-6 border-t border-purple-700/50 bg-purple-950/50"><p class="text-sm text-purple-400">Summary generated in 1.2 seconds • Privacy-focused analysis</p> `);
    Button($$payload, {
      onclick: closeModal,
      class: "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white",
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->Close`);
      },
      $$slots: { default: true }
    });
    $$payload.out.push(`<!----></div></div></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  pop();
}
function NewsCarousel($$payload) {
  let scrollContainer = void 0;
  const newsItems = [
    {
      title: "New Privacy Regulations Take Effect in EU",
      source: "Privacy News",
      time: "2h ago",
      category: "Policy",
      image: "/placeholder.svg?height=120&width=200",
      url: "https://privacy-news.com/eu-regulations"
    },
    {
      title: "Major Data Breach Affects 50M Users",
      source: "Security Today",
      time: "4h ago",
      category: "Security",
      image: "/placeholder.svg?height=120&width=200",
      url: "https://security-today.com/data-breach"
    },
    {
      title: "Signal Introduces New Privacy Features",
      source: "Tech Privacy",
      time: "6h ago",
      category: "Apps",
      image: "/placeholder.svg?height=120&width=200",
      url: "https://tech-privacy.com/signal-features"
    },
    {
      title: "Apple Enhances Safari Privacy Controls",
      source: "Apple Insider",
      time: "8h ago",
      category: "Browsers",
      image: "/placeholder.svg?height=120&width=200",
      url: "https://apple-insider.com/safari-privacy"
    },
    {
      title: "VPN Usage Surges 300% This Year",
      source: "Digital Trends",
      time: "12h ago",
      category: "VPN",
      image: "/placeholder.svg?height=120&width=200",
      url: "https://digital-trends.com/vpn-usage"
    },
    {
      title: "Google Faces New Privacy Lawsuit",
      source: "Legal Tech",
      time: "1d ago",
      category: "Legal",
      image: "/placeholder.svg?height=120&width=200",
      url: "https://legal-tech.com/google-lawsuit"
    }
  ];
  function scrollLeft() {
    scrollContainer.scrollBy({ left: -300, behavior: "smooth" });
  }
  function scrollRight() {
    scrollContainer.scrollBy({ left: 300, behavior: "smooth" });
  }
  function getCategoryColor(category) {
    const colors = {
      "Policy": "bg-blue-500/20 text-blue-400 border-blue-500/30",
      "Security": "bg-red-500/20 text-red-400 border-red-500/30",
      "Apps": "bg-green-500/20 text-green-400 border-green-500/30",
      "Browsers": "bg-purple-500/20 text-purple-400 border-purple-500/30",
      "VPN": "bg-orange-500/20 text-orange-400 border-orange-500/30",
      "Legal": "bg-gray-500/20 text-gray-400 border-gray-500/30"
    };
    return colors[category] || colors["Policy"];
  }
  Card($$payload, {
    class: "border-purple-700/30 bg-purple-900/20 backdrop-blur-sm shadow-sm",
    children: ($$payload2) => {
      Card_content($$payload2, {
        class: "p-6",
        children: ($$payload3) => {
          const each_array = ensure_array_like(newsItems);
          $$payload3.out.push(`<div class="flex items-center justify-between mb-6"><div class="flex items-center gap-3"><div class="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-red-500">`);
          Trending_up($$payload3, { class: "h-4 w-4 text-white" });
          $$payload3.out.push(`<!----></div> <h3 class="text-lg font-semibold text-white">Latest Privacy News</h3></div> <div class="flex gap-2">`);
          Button($$payload3, {
            variant: "outline",
            size: "sm",
            onclick: scrollLeft,
            class: "h-8 w-8 p-0 border-purple-600 text-purple-300 hover:bg-purple-800/30 hover:text-white",
            children: ($$payload4) => {
              Chevron_left($$payload4, { class: "h-4 w-4" });
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----> `);
          Button($$payload3, {
            variant: "outline",
            size: "sm",
            onclick: scrollRight,
            class: "h-8 w-8 p-0 border-purple-600 text-purple-300 hover:bg-purple-800/30 hover:text-white",
            children: ($$payload4) => {
              Chevron_right($$payload4, { class: "h-4 w-4" });
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----></div></div> <div class="flex gap-4 overflow-x-auto scrollbar-hide pb-2 svelte-1if8uxz" style="scroll-snap-type: x mandatory;"><!--[-->`);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let item = each_array[$$index];
            $$payload3.out.push(`<div class="flex-shrink-0 w-72" style="scroll-snap-align: start;">`);
            Card($$payload3, {
              class: "border-purple-700/30 bg-purple-900/30 hover:shadow-md transition-all duration-200 cursor-pointer group",
              children: ($$payload4) => {
                Card_content($$payload4, {
                  class: "p-0",
                  children: ($$payload5) => {
                    $$payload5.out.push(`<div class="relative"><img${attr("src", item.image || "/placeholder.svg")}${attr("alt", item.title)} class="w-full h-32 object-cover rounded-t-lg"/> <div class="absolute top-3 left-3">`);
                    Badge($$payload5, {
                      variant: "secondary",
                      class: getCategoryColor(item.category),
                      children: ($$payload6) => {
                        $$payload6.out.push(`<!---->${escape_html(item.category)}`);
                      },
                      $$slots: { default: true }
                    });
                    $$payload5.out.push(`<!----></div></div> <div class="p-4"><h4 class="font-semibold text-white mb-2 line-clamp-2 group-hover:text-purple-400 transition-colors svelte-1if8uxz">${escape_html(item.title)}</h4> <div class="flex items-center justify-between text-sm text-purple-400"><span>${escape_html(item.source)}</span> <div class="flex items-center gap-1">`);
                    Clock($$payload5, { class: "h-3 w-3" });
                    $$payload5.out.push(`<!----> <span>${escape_html(item.time)}</span></div></div> <a${attr("href", item.url)} class="inline-flex items-center gap-1 text-sm text-purple-400 hover:text-purple-300 mt-2 transition-colors">Read more `);
                    External_link($$payload5, { class: "h-3 w-3" });
                    $$payload5.out.push(`<!----></a></div>`);
                  },
                  $$slots: { default: true }
                });
              },
              $$slots: { default: true }
            });
            $$payload3.out.push(`<!----></div>`);
          }
          $$payload3.out.push(`<!--]--></div>`);
        },
        $$slots: { default: true }
      });
    },
    $$slots: { default: true }
  });
}
function CurrencyExchange($$payload, $$props) {
  push();
  let { query } = $$props;
  let fromCurrency = "USD";
  let toCurrency = "EUR";
  let amount = 1;
  let isLoading = false;
  const exchangeRates = {
    "USD": {
      "EUR": 0.85,
      "GBP": 0.73,
      "JPY": 110.25,
      "BTC": 23e-6,
      "ETH": 41e-5,
      "SOL": 89e-4
    },
    "EUR": {
      "USD": 1.18,
      "GBP": 0.86,
      "JPY": 129.5,
      "BTC": 27e-6,
      "ETH": 48e-5,
      "SOL": 0.0105
    },
    "GBP": {
      "USD": 1.37,
      "EUR": 1.16,
      "JPY": 150.75,
      "BTC": 31e-6,
      "ETH": 56e-5,
      "SOL": 0.0122
    },
    "BTC": {
      "USD": 43500,
      "EUR": 36900,
      "GBP": 32100,
      "JPY": 4785e3,
      "ETH": 17.8,
      "SOL": 387.2
    },
    "ETH": {
      "USD": 2450,
      "EUR": 2080,
      "GBP": 1790,
      "JPY": 269500,
      "BTC": 0.056,
      "SOL": 21.8
    },
    "SOL": {
      "USD": 112.5,
      "EUR": 95.6,
      "GBP": 82.1,
      "JPY": 12375,
      "BTC": 258e-5,
      "ETH": 0.046
    }
  };
  const currencies = ["USD", "EUR", "GBP", "JPY", "BTC", "ETH", "SOL"];
  function parseCurrencyQuery(query2) {
    const match = query2.match(/(\w{3})\s+to\s+(\w{3})/i);
    if (match) {
      return { from: match[1].toUpperCase(), to: match[2].toUpperCase() };
    }
    return { from: "USD", to: "EUR" };
  }
  const initialParse = parseCurrencyQuery(query);
  fromCurrency = initialParse.from;
  toCurrency = initialParse.to;
  function getExchangeRate() {
    return exchangeRates[fromCurrency]?.[toCurrency] || 1;
  }
  function getConvertedAmount() {
    return (amount * getExchangeRate()).toFixed(6);
  }
  function swapCurrencies() {
    const temp = fromCurrency;
    fromCurrency = toCurrency;
    toCurrency = temp;
  }
  function refreshRates() {
    isLoading = true;
    setTimeout(
      () => {
        isLoading = false;
      },
      1e3
    );
  }
  function getCurrencySymbol(currency) {
    const symbols = {
      "USD": "$",
      "EUR": "€",
      "GBP": "£",
      "JPY": "¥",
      "BTC": "₿",
      "ETH": "Ξ",
      "SOL": "◎"
    };
    return symbols[currency] || currency;
  }
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    Card($$payload2, {
      class: "border-purple-700/30 bg-gradient-to-r from-green-900/20 to-blue-900/20 backdrop-blur-sm shadow-sm",
      children: ($$payload3) => {
        Card_content($$payload3, {
          class: "p-6",
          children: ($$payload4) => {
            const each_array = ensure_array_like(currencies);
            const each_array_1 = ensure_array_like(currencies);
            const each_array_2 = ensure_array_like([1, 10, 100, 1e3]);
            $$payload4.out.push(`<div class="flex flex-col sm:flex-row items-start sm:items-center gap-4"><div class="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-green-500 to-blue-500 flex-shrink-0">`);
            Dollar_sign($$payload4, { class: "h-5 w-5 text-white" });
            $$payload4.out.push(`<!----></div> <div class="flex-1 w-full"><div class="flex flex-col sm:flex-row items-start sm:items-center gap-2 mb-4"><h3 class="text-lg font-semibold text-white">Currency Exchange</h3> `);
            Badge($$payload4, {
              variant: "secondary",
              class: "bg-green-500/20 text-green-400 border-green-500/30",
              children: ($$payload5) => {
                Trending_up($$payload5, { class: "h-3 w-3 mr-1" });
                $$payload5.out.push(`<!----> Live Rates`);
              },
              $$slots: { default: true }
            });
            $$payload4.out.push(`<!----> `);
            Button($$payload4, {
              variant: "ghost",
              size: "sm",
              onclick: refreshRates,
              disabled: isLoading,
              class: "sm:ml-auto text-purple-300 hover:text-white hover:bg-purple-800/30",
              children: ($$payload5) => {
                Refresh_cw($$payload5, { class: `h-4 w-4 ${isLoading ? "animate-spin" : ""}` });
              },
              $$slots: { default: true }
            });
            $$payload4.out.push(`<!----></div> <div class="grid gap-4 md:grid-cols-2 relative"><div class="bg-purple-900/30 rounded-lg p-4 border border-purple-700/30"><div class="flex items-center gap-2 mb-3"><span class="text-purple-300 text-sm">From</span> <select class="bg-purple-800/50 border border-purple-600/50 rounded px-2 py-1 text-white text-sm focus:outline-none focus:border-purple-500">`);
            $$payload4.select_value = fromCurrency;
            $$payload4.out.push(`<!--[-->`);
            for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
              let currency = each_array[$$index];
              $$payload4.out.push(`<option${attr("value", currency)}${maybe_selected($$payload4, currency)}>${escape_html(currency)}</option>`);
            }
            $$payload4.out.push(`<!--]-->`);
            $$payload4.select_value = void 0;
            $$payload4.out.push(`</select></div> <div class="flex items-center gap-2"><span class="text-lg text-purple-300">${escape_html(getCurrencySymbol(fromCurrency))}</span> `);
            Input($$payload4, {
              type: "number",
              min: "0",
              step: "0.01",
              class: "bg-transparent border-none text-2xl font-bold text-white p-0 focus:ring-0 focus:border-none",
              placeholder: "1.00",
              get value() {
                return amount;
              },
              set value($$value) {
                amount = $$value;
                $$settled = false;
              }
            });
            $$payload4.out.push(`<!----></div></div> <div class="flex items-center justify-center md:absolute md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:z-10 svelte-4ta7hj">`);
            Button($$payload4, {
              variant: "outline",
              size: "sm",
              onclick: swapCurrencies,
              class: "bg-purple-900/50 border-purple-600 text-purple-300 hover:bg-purple-800/50 hover:text-white rounded-full h-10 w-10 p-0",
              children: ($$payload5) => {
                Arrow_right_left($$payload5, { class: "h-4 w-4" });
              },
              $$slots: { default: true }
            });
            $$payload4.out.push(`<!----></div> <div class="bg-purple-900/30 rounded-lg p-4 border border-purple-700/30"><div class="flex items-center gap-2 mb-3"><span class="text-purple-300 text-sm">To</span> <select class="bg-purple-800/50 border border-purple-600/50 rounded px-2 py-1 text-white text-sm focus:outline-none focus:border-purple-500">`);
            $$payload4.select_value = toCurrency;
            $$payload4.out.push(`<!--[-->`);
            for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
              let currency = each_array_1[$$index_1];
              $$payload4.out.push(`<option${attr("value", currency)}${maybe_selected($$payload4, currency)}>${escape_html(currency)}</option>`);
            }
            $$payload4.out.push(`<!--]-->`);
            $$payload4.select_value = void 0;
            $$payload4.out.push(`</select></div> <div class="flex items-center gap-2"><span class="text-lg text-purple-300">${escape_html(getCurrencySymbol(toCurrency))}</span> <div class="text-2xl font-bold text-green-400">${escape_html(getConvertedAmount())}</div></div></div></div> <div class="mt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between text-sm"><div class="flex items-center gap-2 text-purple-300 mb-2 sm:mb-0">`);
            Arrow_right_left($$payload4, { class: "h-4 w-4" });
            $$payload4.out.push(`<!----> <span>1 ${escape_html(fromCurrency)} = ${escape_html(getExchangeRate().toLocaleString())} ${escape_html(toCurrency)}</span></div> <span class="text-purple-400">Updated 2 minutes ago</span></div> <div class="mt-4 flex flex-wrap gap-2 items-center"><span class="text-sm text-purple-300 self-center">Quick:</span> <!--[-->`);
            for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
              let quickAmount = each_array_2[$$index_2];
              Button($$payload4, {
                variant: "outline",
                size: "sm",
                onclick: () => amount = quickAmount,
                class: "border-purple-600/50 text-purple-300 hover:bg-purple-800/30 hover:text-white text-xs",
                children: ($$payload5) => {
                  $$payload5.out.push(`<!---->${escape_html(quickAmount)}`);
                },
                $$slots: { default: true }
              });
            }
            $$payload4.out.push(`<!--]--></div></div></div>`);
          },
          $$slots: { default: true }
        });
      },
      $$slots: { default: true }
    });
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
function WeatherWidget($$payload, $$props) {
  let { query } = $$props;
  function parseLocation(query2) {
    const match = query2.match(/weather\s+in\s+(.+)/i) || query2.match(/(.+)\s+weather/i);
    return match ? match[1].trim() : "New York";
  }
  const location = parseLocation(query);
  const weatherData = {
    location,
    temperature: 22,
    condition: "Partly Cloudy",
    humidity: 65,
    windSpeed: 12,
    forecast: [
      { day: "Today", high: 24, low: 18, condition: "Partly Cloudy" },
      { day: "Tomorrow", high: 26, low: 20, condition: "Sunny" },
      { day: "Wednesday", high: 23, low: 17, condition: "Rainy" }
    ]
  };
  Card($$payload, {
    class: "border-purple-700/30 bg-gradient-to-r from-blue-900/20 to-purple-900/20 backdrop-blur-sm shadow-sm",
    children: ($$payload2) => {
      Card_content($$payload2, {
        class: "p-6",
        children: ($$payload3) => {
          const each_array = ensure_array_like(weatherData.forecast);
          $$payload3.out.push(`<div class="flex items-start gap-4"><div class="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex-shrink-0">`);
          Cloud($$payload3, { class: "h-5 w-5 text-white" });
          $$payload3.out.push(`<!----></div> <div class="flex-1"><div class="flex items-center gap-2 mb-4"><h3 class="text-lg font-semibold text-white">Weather</h3> `);
          Badge($$payload3, {
            variant: "secondary",
            class: "bg-blue-500/20 text-blue-400 border-blue-500/30",
            children: ($$payload4) => {
              Thermometer($$payload4, { class: "h-3 w-3 mr-1" });
              $$payload4.out.push(`<!----> Current`);
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----></div> <div class="grid gap-4 md:grid-cols-2"><div class="bg-purple-900/30 rounded-lg p-4 border border-purple-700/30"><div class="flex items-center justify-between mb-2"><span class="text-purple-300 text-sm">${escape_html(weatherData.location)}</span> `);
          Sun($$payload3, { class: "h-5 w-5 text-yellow-400" });
          $$payload3.out.push(`<!----></div> <div class="text-3xl font-bold text-white mb-1">${escape_html(weatherData.temperature)}°C</div> <div class="text-purple-300 text-sm">${escape_html(weatherData.condition)}</div></div> <div class="space-y-3"><div class="flex items-center gap-3 text-sm">`);
          Droplets($$payload3, { class: "h-4 w-4 text-blue-400" });
          $$payload3.out.push(`<!----> <span class="text-purple-300">Humidity</span> <span class="text-white ml-auto">${escape_html(weatherData.humidity)}%</span></div> <div class="flex items-center gap-3 text-sm">`);
          Wind($$payload3, { class: "h-4 w-4 text-gray-400" });
          $$payload3.out.push(`<!----> <span class="text-purple-300">Wind Speed</span> <span class="text-white ml-auto">${escape_html(weatherData.windSpeed)} km/h</span></div></div></div> <div class="mt-4 grid grid-cols-3 gap-2"><!--[-->`);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let day = each_array[$$index];
            $$payload3.out.push(`<div class="bg-purple-900/20 rounded-lg p-3 text-center border border-purple-700/20"><div class="text-xs text-purple-300 mb-1">${escape_html(day.day)}</div> <div class="text-sm font-semibold text-white">${escape_html(day.high)}°/${escape_html(day.low)}°</div> <div class="text-xs text-purple-400 mt-1">${escape_html(day.condition)}</div></div>`);
          }
          $$payload3.out.push(`<!--]--></div></div></div>`);
        },
        $$slots: { default: true }
      });
    },
    $$slots: { default: true }
  });
}
function SpecificAnswer($$payload, $$props) {
  push();
  let { data } = $$props;
  const answers = {
    "bitcoin": {
      title: "What is Bitcoin?",
      answer: "Bitcoin is a decentralized digital currency that operates without a central bank or single administrator. It uses blockchain technology to enable peer-to-peer transactions and is secured by cryptographic proof.",
      source: "Cryptocurrency Encyclopedia",
      icon: Circle_check_big
    },
    "encrypt files": {
      title: "How to encrypt files",
      answer: "File encryption converts your data into unreadable code using algorithms. You can use built-in tools like BitLocker (Windows) or FileVault (Mac), or third-party software like VeraCrypt for cross-platform encryption.",
      source: "Security Best Practices",
      icon: Circle_check_big
    }
  };
  function getAnswer(query) {
    const lowerQuery = query.toLowerCase();
    for (const [key, value] of Object.entries(answers)) {
      if (lowerQuery.includes(key)) {
        return value;
      }
    }
    return {
      title: `About "${data.query}"`,
      answer: `Based on your search for "${data.query}", here's what we found: This appears to be a ${data.type} query. Our privacy-focused search provides comprehensive results while protecting your data.`,
      source: "Breeze Knowledge Base",
      icon: Brain
    };
  }
  const answer = getAnswer(data.fullQuery);
  const IconComponent = answer.icon;
  Card($$payload, {
    class: "border-purple-700/30 bg-gradient-to-r from-purple-900/30 to-blue-900/20 backdrop-blur-sm shadow-sm",
    children: ($$payload2) => {
      Card_content($$payload2, {
        class: "p-6",
        children: ($$payload3) => {
          $$payload3.out.push(`<div class="flex items-start gap-4"><div class="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex-shrink-0">`);
          IconComponent($$payload3, { class: "h-5 w-5 text-white" });
          $$payload3.out.push(`<!----></div> <div class="flex-1"><div class="flex items-center gap-2 mb-3"><h3 class="text-lg font-semibold text-white">${escape_html(answer.title)}</h3> `);
          Badge($$payload3, {
            variant: "secondary",
            class: "bg-purple-500/20 text-purple-400 border-purple-500/30",
            children: ($$payload4) => {
              Brain($$payload4, { class: "h-3 w-3 mr-1" });
              $$payload4.out.push(`<!----> Direct Answer`);
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----></div> <p class="text-purple-200 leading-relaxed mb-4">${escape_html(answer.answer)}</p> <div class="flex items-center gap-2 text-sm text-purple-400">`);
          Circle_check_big($$payload3, { class: "h-4 w-4" });
          $$payload3.out.push(`<!----> <span>Source: ${escape_html(answer.source)}</span></div></div></div>`);
        },
        $$slots: { default: true }
      });
    },
    $$slots: { default: true }
  });
  pop();
}
function SolanaExplorer($$payload, $$props) {
  push();
  let { query, queryType } = $$props;
  let network = "mainnet";
  let isLoading = false;
  let copied = false;
  let explorerData = null;
  const mockAddressData = {
    address: query,
    balance: 12.45,
    tokenAccounts: 8,
    transactions: 1247,
    firstSeen: "2023-08-15",
    lastActivity: "2 hours ago",
    tokens: [
      { symbol: "SOL", amount: 12.45, value: 1398.75 },
      { symbol: "USDC", amount: 250, value: 250 },
      { symbol: "RAY", amount: 89.32, value: 156.78 }
    ]
  };
  const mockTransactionData = {
    signature: query,
    status: "Success",
    block: 234567890,
    timestamp: "2024-01-15 14:32:18 UTC",
    fee: 5e-6,
    from: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",
    to: "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM",
    amount: 5.25,
    programId: "11111111111111111111111111111112"
  };
  function toggleNetwork() {
    network = network === "mainnet" ? "devnet" : "mainnet";
    fetchExplorerData();
  }
  function copyToClipboard() {
    navigator.clipboard.writeText(query);
    copied = true;
    setTimeout(() => copied = false, 2e3);
  }
  function fetchExplorerData() {
    isLoading = true;
    setTimeout(
      () => {
        explorerData = queryType === "address" ? mockAddressData : mockTransactionData;
        isLoading = false;
      },
      1e3
    );
  }
  function openInExplorer() {
    const baseUrl = network === "mainnet" ? "https://explorer.solana.com" : "https://explorer.solana.com?cluster=devnet";
    const path = queryType === "address" ? "address" : "tx";
    window.open(`${baseUrl}/${path}/${query}`, "_blank");
  }
  Card($$payload, {
    class: "border-purple-700/30 bg-gradient-to-r from-purple-900/20 to-blue-900/20 backdrop-blur-sm shadow-sm",
    children: ($$payload2) => {
      Card_content($$payload2, {
        class: "p-6",
        children: ($$payload3) => {
          $$payload3.out.push(`<div class="flex flex-col sm:flex-row items-start sm:items-center gap-4"><div class="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex-shrink-0">`);
          Zap($$payload3, { class: "h-5 w-5 text-white" });
          $$payload3.out.push(`<!----></div> <div class="flex-1 w-full"><div class="flex flex-col sm:flex-row items-start sm:items-center gap-2 mb-4"><h3 class="text-lg font-semibold text-white">Solana ${escape_html(queryType === "address" ? "Address" : "Transaction")}</h3> `);
          Badge($$payload3, {
            variant: "secondary",
            class: "bg-purple-500/20 text-purple-400 border-purple-500/30",
            children: ($$payload4) => {
              Zap($$payload4, { class: "h-3 w-3 mr-1" });
              $$payload4.out.push(`<!----> Blockchain`);
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----> <div class="sm:ml-auto flex items-center gap-2 mt-2 sm:mt-0">`);
          Button($$payload3, {
            variant: "outline",
            size: "sm",
            onclick: toggleNetwork,
            class: `border-purple-600 text-purple-300 hover:text-white ${network === "mainnet" ? "bg-green-500/20 hover:bg-green-500/30" : "bg-orange-500/20 hover:bg-orange-500/30"}`,
            children: ($$payload4) => {
              if (network === "mainnet") {
                $$payload4.out.push("<!--[-->");
                Globe($$payload4, { class: "h-3 w-3 mr-1" });
                $$payload4.out.push(`<!----> Mainnet`);
              } else {
                $$payload4.out.push("<!--[!-->");
                Test_tube($$payload4, { class: "h-3 w-3 mr-1" });
                $$payload4.out.push(`<!----> Devnet`);
              }
              $$payload4.out.push(`<!--]-->`);
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----> `);
          Button($$payload3, {
            variant: "ghost",
            size: "sm",
            onclick: openInExplorer,
            class: "text-purple-300 hover:text-white hover:bg-purple-800/30",
            children: ($$payload4) => {
              External_link($$payload4, { class: "h-4 w-4" });
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----></div></div> <div class="bg-purple-900/30 rounded-lg p-3 border border-purple-700/30 mb-4"><div class="flex items-center gap-2"><span class="text-purple-300 text-sm font-mono break-all">${escape_html(query)}</span> `);
          Button($$payload3, {
            variant: "ghost",
            size: "sm",
            onclick: copyToClipboard,
            class: "text-purple-400 hover:text-white hover:bg-purple-800/30 flex-shrink-0",
            children: ($$payload4) => {
              if (copied) {
                $$payload4.out.push("<!--[-->");
                Circle_check_big($$payload4, { class: "h-3 w-3" });
              } else {
                $$payload4.out.push("<!--[!-->");
                Copy($$payload4, { class: "h-3 w-3" });
              }
              $$payload4.out.push(`<!--]-->`);
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----></div></div> `);
          if (isLoading) {
            $$payload3.out.push("<!--[-->");
            $$payload3.out.push(`<div class="flex items-center gap-3 py-8"><div class="h-6 w-6 animate-spin rounded-full border-2 border-purple-500/30 border-t-purple-500"></div> <p class="text-purple-200">Loading ${escape_html(network)} data...</p></div>`);
          } else {
            $$payload3.out.push("<!--[!-->");
            if (explorerData) {
              $$payload3.out.push("<!--[-->");
              if (queryType === "address") {
                $$payload3.out.push("<!--[-->");
                const each_array = ensure_array_like(explorerData.tokens);
                $$payload3.out.push(`<div class="grid gap-4 md:grid-cols-2"><div class="space-y-3"><div class="flex items-center justify-between"><span class="text-purple-300 text-sm">Balance</span> <span class="text-white font-semibold">${escape_html(explorerData.balance)} SOL</span></div> <div class="flex items-center justify-between"><span class="text-purple-300 text-sm">Token Accounts</span> <span class="text-white font-semibold">${escape_html(explorerData.tokenAccounts)}</span></div> <div class="flex items-center justify-between"><span class="text-purple-300 text-sm">Transactions</span> <span class="text-white font-semibold">${escape_html(explorerData.transactions.toLocaleString())}</span></div> <div class="flex items-center justify-between"><span class="text-purple-300 text-sm">Last Activity</span> <span class="text-green-400 font-semibold">${escape_html(explorerData.lastActivity)}</span></div></div> <div class="bg-purple-900/20 rounded-lg p-3 border border-purple-700/20 mt-4 md:mt-0"><h4 class="text-white font-semibold mb-2 text-sm">Token Holdings</h4> <div class="space-y-2"><!--[-->`);
                for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
                  let token = each_array[$$index];
                  $$payload3.out.push(`<div class="flex items-center justify-between text-sm"><span class="text-purple-300">${escape_html(token.symbol)}</span> <div class="text-right"><div class="text-white">${escape_html(token.amount)}</div> <div class="text-purple-400 text-xs">$${escape_html(token.value)}</div></div></div>`);
                }
                $$payload3.out.push(`<!--]--></div></div></div>`);
              } else {
                $$payload3.out.push("<!--[!-->");
                $$payload3.out.push(`<div class="space-y-4"><div class="flex flex-wrap items-center gap-2">`);
                Badge($$payload3, {
                  variant: "secondary",
                  class: explorerData.status === "Success" ? "bg-green-500/20 text-green-400 border-green-500/30" : "bg-red-500/20 text-red-400 border-red-500/30",
                  children: ($$payload4) => {
                    if (explorerData.status === "Success") {
                      $$payload4.out.push("<!--[-->");
                      Circle_check_big($$payload4, { class: "h-3 w-3 mr-1" });
                    } else {
                      $$payload4.out.push("<!--[!-->");
                      Circle_alert($$payload4, { class: "h-3 w-3 mr-1" });
                    }
                    $$payload4.out.push(`<!--]--> ${escape_html(explorerData.status)}`);
                  },
                  $$slots: { default: true }
                });
                $$payload3.out.push(`<!----> <span class="text-purple-300 text-sm">Block #${escape_html(explorerData.block.toLocaleString())}</span></div> <div class="grid gap-3 md:grid-cols-2"><div class="space-y-2"><div class="flex items-center justify-between"><span class="text-purple-300 text-sm">Amount</span> <span class="text-white font-semibold">${escape_html(explorerData.amount)} SOL</span></div> <div class="flex items-center justify-between"><span class="text-purple-300 text-sm">Fee</span> <span class="text-purple-400">${escape_html(explorerData.fee)} SOL</span></div> <div class="flex items-center justify-between"><span class="text-purple-300 text-sm">Timestamp</span> <span class="text-purple-400 text-xs">${escape_html(explorerData.timestamp)}</span></div></div> <div class="space-y-2 mt-4 md:mt-0"><div><span class="text-purple-300 text-sm block">From</span> <span class="text-white text-xs font-mono break-all">${escape_html(explorerData.from)}</span></div> <div><span class="text-purple-300 text-sm block">To</span> <span class="text-white text-xs font-mono break-all">${escape_html(explorerData.to)}</span></div></div></div></div>`);
              }
              $$payload3.out.push(`<!--]-->`);
            } else {
              $$payload3.out.push("<!--[!-->");
            }
            $$payload3.out.push(`<!--]-->`);
          }
          $$payload3.out.push(`<!--]--></div></div>`);
        },
        $$slots: { default: true }
      });
    },
    $$slots: { default: true }
  });
  pop();
}
function TokenPriceChart($$payload, $$props) {
  push();
  let { tokenSymbol } = $$props;
  let isLoading = false;
  const mockTokenData = {
    "SOL": {
      name: "Solana",
      currentPrice: 115.23,
      change24h: 3.56,
      // positive change
      changePercent24h: 3.19,
      marketCap: 50.2,
      // in billions
      volume24h: 1.8,
      // in billions
      history: [
        { price: 110, date: "Mon" },
        { price: 112, date: "Tue" },
        { price: 111, date: "Wed" },
        { price: 113, date: "Thu" },
        { price: 115, date: "Fri" },
        { price: 114, date: "Sat" },
        { price: 115.23, date: "Sun" }
      ]
    },
    "BTC": {
      name: "Bitcoin",
      currentPrice: 68500.75,
      change24h: -1200.5,
      // negative change
      changePercent24h: -1.72,
      marketCap: 1.3,
      // in trillions
      volume24h: 25.5,
      // in billions
      history: [
        { price: 69e3, date: "Mon" },
        { price: 68800, date: "Tue" },
        { price: 69500, date: "Wed" },
        { price: 68e3, date: "Thu" },
        { price: 68700, date: "Fri" },
        { price: 68200, date: "Sat" },
        { price: 68500.75, date: "Sun" }
      ]
    },
    "ETH": {
      name: "Ethereum",
      currentPrice: 3820.1,
      change24h: 85.2,
      // positive change
      changePercent24h: 2.28,
      marketCap: 458,
      // in billions
      volume24h: 12.1,
      // in billions
      history: [
        { price: 3750, date: "Mon" },
        { price: 3780, date: "Tue" },
        { price: 3760, date: "Wed" },
        { price: 3800, date: "Thu" },
        { price: 3810, date: "Fri" },
        { price: 3790, date: "Sat" },
        { price: 3820.1, date: "Sun" }
      ]
    }
  };
  let tokenData = mockTokenData[tokenSymbol] || null;
  function fetchTokenData() {
    isLoading = true;
    setTimeout(
      () => {
        tokenData = mockTokenData[tokenSymbol] || null;
        isLoading = false;
      },
      800
    );
  }
  function getPriceChangeColor(change) {
    return change >= 0 ? "text-green-400" : "text-red-400";
  }
  function getPriceChangeIcon(change) {
    return change >= 0 ? Trending_up : Trending_down;
  }
  function getChartPoints() {
    if (!tokenData || !tokenData.history || tokenData.history.length < 2) return "";
    const prices = tokenData.history.map((d) => d.price);
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const priceRange = maxPrice - minPrice;
    const points = tokenData.history.map((data, i) => {
      const x = i / (tokenData.history.length - 1) * 100;
      const y = priceRange > 0 ? 100 - (data.price - minPrice) / priceRange * 100 : 50;
      return `${x},${y}`;
    }).join(" ");
    return points;
  }
  Card($$payload, {
    class: "border-purple-700/30 bg-gradient-to-r from-blue-900/20 to-green-900/20 backdrop-blur-sm shadow-sm",
    children: ($$payload2) => {
      Card_content($$payload2, {
        class: "p-6",
        children: ($$payload3) => {
          $$payload3.out.push(`<div class="flex flex-col sm:flex-row items-start sm:items-center gap-4"><div class="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-green-500 flex-shrink-0">`);
          Chart_line($$payload3, { class: "h-5 w-5 text-white" });
          $$payload3.out.push(`<!----></div> <div class="flex-1 w-full"><div class="flex flex-col sm:flex-row items-start sm:items-center gap-2 mb-4"><h3 class="text-lg font-semibold text-white">${escape_html(tokenData?.name || tokenSymbol)} Price Chart</h3> `);
          Badge($$payload3, {
            variant: "secondary",
            class: "bg-blue-500/20 text-blue-400 border-blue-500/30",
            children: ($$payload4) => {
              Dollar_sign($$payload4, { class: "h-3 w-3 mr-1" });
              $$payload4.out.push(`<!----> Crypto`);
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----> `);
          Button($$payload3, {
            variant: "ghost",
            size: "sm",
            onclick: fetchTokenData,
            disabled: isLoading,
            class: "sm:ml-auto text-purple-300 hover:text-white hover:bg-purple-800/30",
            children: ($$payload4) => {
              Refresh_cw($$payload4, { class: `h-4 w-4 ${isLoading ? "animate-spin" : ""}` });
            },
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----></div> `);
          if (isLoading) {
            $$payload3.out.push("<!--[-->");
            $$payload3.out.push(`<div class="flex items-center gap-3 py-8"><div class="h-6 w-6 animate-spin rounded-full border-2 border-purple-500/30 border-t-purple-500"></div> <p class="text-purple-200">Loading price data...</p></div>`);
          } else {
            $$payload3.out.push("<!--[!-->");
            if (tokenData) {
              $$payload3.out.push("<!--[-->");
              const SvelteComponent = getPriceChangeIcon(tokenData.change24h);
              const each_array = ensure_array_like(tokenData.history);
              $$payload3.out.push(`<div class="grid gap-4 md:grid-cols-2"><div class="bg-purple-900/30 rounded-lg p-4 border border-purple-700/30"><div class="flex items-center justify-between mb-2"><span class="text-purple-300 text-sm">Current Price</span> <span class="text-white font-semibold">${escape_html(tokenSymbol)}</span></div> <div class="text-3xl font-bold text-white mb-1">$${escape_html(tokenData.currentPrice.toLocaleString())}</div> <div${attr_class(`flex items-center gap-2 text-sm ${stringify(getPriceChangeColor(tokenData.change24h))}`)}><!---->`);
              SvelteComponent($$payload3, { class: "h-4 w-4" });
              $$payload3.out.push(`<!----> <span>${escape_html(tokenData.change24h.toFixed(2))} (${escape_html(tokenData.changePercent24h.toFixed(2))}%)</span> <span class="text-purple-300 ml-auto">24h Change</span></div></div> <div class="bg-purple-900/30 rounded-lg p-4 border border-purple-700/30 mt-4 md:mt-0"><h4 class="text-white font-semibold mb-2 text-sm">Market Stats</h4> <div class="space-y-2"><div class="flex items-center justify-between text-sm"><span class="text-purple-300">Market Cap</span> <span class="text-white">$${escape_html(tokenData.marketCap.toLocaleString())}B</span></div> <div class="flex items-center justify-between text-sm"><span class="text-purple-300">24h Volume</span> <span class="text-white">$${escape_html(tokenData.volume24h.toLocaleString())}B</span></div> <div class="flex items-center justify-between text-sm"><span class="text-purple-300">Last Updated</span> <span class="text-purple-400 text-xs flex items-center gap-1">`);
              Clock($$payload3, { class: "h-3 w-3" });
              $$payload3.out.push(`<!----> Just now</span></div></div></div></div> <div class="mt-6 bg-purple-900/30 rounded-lg p-4 border border-purple-700/30"><h4 class="text-white font-semibold mb-4">7-Day Price History</h4> <div class="relative h-40 w-full"><svg viewBox="0 0 100 100" preserveAspectRatio="none" class="w-full h-full"><polyline fill="none"${attr("stroke", tokenData.change24h >= 0 ? "url(#gradient-green)" : "url(#gradient-red)")} stroke-width="2"${attr("points", getChartPoints())}></polyline><defs><linearGradient id="gradient-green" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="#86EFAC"></stop><stop offset="100%" stop-color="#22C55E"></stop></linearGradient><linearGradient id="gradient-red" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="#FCA5A5"></stop><stop offset="100%" stop-color="#EF4444"></stop></linearGradient></defs></svg> <div class="absolute inset-x-0 bottom-0 flex justify-between text-xs text-purple-400 px-2 pb-1"><!--[-->`);
              for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
                let data = each_array[$$index];
                $$payload3.out.push(`<span>${escape_html(data.date)}</span>`);
              }
              $$payload3.out.push(`<!--]--></div></div></div>`);
            } else {
              $$payload3.out.push("<!--[!-->");
              $$payload3.out.push(`<div class="text-purple-300 text-center py-8">No price data available for ${escape_html(tokenSymbol)}.</div>`);
            }
            $$payload3.out.push(`<!--]-->`);
          }
          $$payload3.out.push(`<!--]--></div></div>`);
        },
        $$slots: { default: true }
      });
    },
    $$slots: { default: true }
  });
  pop();
}
function SearchResultSkeleton($$payload) {
  Card($$payload, {
    class: "border-purple-700/30 bg-purple-900/20 backdrop-blur-sm shadow-sm animate-pulse",
    children: ($$payload2) => {
      Card_content($$payload2, {
        class: "p-6",
        children: ($$payload3) => {
          $$payload3.out.push(`<div class="flex items-start gap-4"><div class="flex-shrink-0 h-8 w-8 rounded-lg bg-purple-800/50"></div> <div class="flex-1 space-y-3"><div class="h-4 bg-purple-800/50 rounded w-3/4"></div> <div class="h-6 bg-purple-800/50 rounded w-full"></div> <div class="h-4 bg-purple-800/50 rounded w-5/6"></div></div></div>`);
        },
        $$slots: { default: true }
      });
    },
    $$slots: { default: true }
  });
}
function App($$payload, $$props) {
  push();
  let searchQuery = "";
  let isSearching = false;
  let hasSearched = false;
  let currentPage = 1;
  let showSuggestions = false;
  let suggestions = [];
  let showExportMenu = false;
  let showCurrencyExchange = false;
  let showWeather = false;
  let showSpecificAnswer = false;
  let specificAnswerData = null;
  let showSolanaExplorer = false;
  let solanaQueryType = "";
  let solanaQuery = "";
  let showTokenPriceChart = false;
  let tokenChartSymbol = "";
  let resultsLoading = false;
  const trendingSearches = [
    "Secure messaging apps",
    "Privacy tools 2024",
    "Open source software",
    "Digital privacy rights",
    "Encrypted cloud storage"
  ];
  const recentSearches = [
    "VPN comparison guide",
    "Privacy-focused browsers",
    "Data protection laws"
  ];
  const allSuggestions = [
    "secure messaging apps",
    "secure email providers",
    "security best practices",
    "privacy tools 2024",
    "privacy-focused browsers",
    "privacy laws",
    "open source software",
    "open source alternatives",
    "digital privacy rights",
    "data protection",
    "encrypted cloud storage",
    "encryption tools",
    "USD to EUR",
    "weather in New York",
    "what is bitcoin",
    "how to encrypt files",
    "SOL price",
    "BTC chart",
    "ETH price"
  ];
  const mockResults = [
    {
      title: "Complete Guide to Digital Privacy in 2024",
      url: "privacy-guide.org",
      domain: "privacy-guide.org",
      description: "Learn essential privacy practices, tools, and techniques to protect your digital footprint. Comprehensive coverage of encryption, secure communications, and data protection.",
      timestamp: "2h ago",
      verified: true,
      hasLogo: true
    },
    {
      title: "Open Source Privacy Tools You Should Know",
      url: "opensource-privacy.com",
      domain: "opensource-privacy.com",
      description: "Discover powerful open-source alternatives to mainstream apps that respect your privacy. From browsers to messaging apps and beyond.",
      timestamp: "4h ago",
      verified: true,
      hasLogo: false
    },
    {
      title: "Understanding Data Collection and Your Rights",
      url: "digital-rights.org",
      domain: "digital-rights.org",
      description: "A deep dive into how companies collect your data, what rights you have, and practical steps to limit unwanted data harvesting.",
      timestamp: "1d ago",
      verified: false,
      hasLogo: true
    },
    {
      title: "Best VPN Services for Privacy in 2024",
      url: "vpn-reviews.net",
      domain: "vpn-reviews.net",
      description: "Comprehensive review of the most trusted VPN services that prioritize user privacy and security. Compare features, pricing, and performance.",
      timestamp: "3h ago",
      verified: true,
      hasLogo: false
    },
    {
      title: "Encrypted Messaging Apps Comparison",
      url: "secure-chat.info",
      domain: "secure-chat.info",
      description: "Compare the security features of popular encrypted messaging apps. Learn about end-to-end encryption, metadata protection, and more.",
      timestamp: "5h ago",
      verified: true,
      hasLogo: true
    }
  ];
  const totalPages = 12;
  const resultsPerPage = 10;
  function detectSearchType(query) {
    const trimmedQuery = query.trim();
    const lowerQuery = trimmedQuery.toLowerCase();
    showCurrencyExchange = false;
    showWeather = false;
    showSpecificAnswer = false;
    specificAnswerData = null;
    showSolanaExplorer = false;
    solanaQueryType = "";
    solanaQuery = "";
    showTokenPriceChart = false;
    tokenChartSymbol = "";
    const solanaAddressPattern = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
    const solanaTransactionPattern = /^[1-9A-HJ-NP-Za-km-z]{80,90}$/;
    if (solanaTransactionPattern.test(trimmedQuery)) {
      showSolanaExplorer = true;
      solanaQueryType = "transaction";
      solanaQuery = trimmedQuery;
    } else if (solanaAddressPattern.test(trimmedQuery)) {
      showSolanaExplorer = true;
      solanaQueryType = "address";
      solanaQuery = trimmedQuery;
    }
    const currencyKeywords = [
      "usd",
      "eur",
      "gbp",
      "jpy",
      "btc",
      "eth",
      "sol",
      "exchange rate",
      "currency",
      "convert",
      "to"
    ];
    const currencyPattern = /(\w{3})\s+to\s+(\w{3})|exchange rate|currency|convert/i;
    if (currencyKeywords.some((keyword) => lowerQuery.includes(keyword)) || currencyPattern.test(lowerQuery)) {
      showCurrencyExchange = true;
    }
    const weatherKeywords = [
      "weather",
      "temperature",
      "forecast",
      "rain",
      "sunny",
      "cloudy",
      "snow",
      "climate"
    ];
    if (weatherKeywords.some((keyword) => lowerQuery.includes(keyword))) {
      showWeather = true;
    }
    const tokenChartKeywords = [
      { keyword: "sol price", symbol: "SOL" },
      { keyword: "sol chart", symbol: "SOL" },
      { keyword: "btc price", symbol: "BTC" },
      { keyword: "btc chart", symbol: "BTC" },
      { keyword: "eth price", symbol: "ETH" },
      { keyword: "eth chart", symbol: "ETH" }
    ];
    for (const { keyword, symbol } of tokenChartKeywords) {
      if (lowerQuery.includes(keyword)) {
        showTokenPriceChart = true;
        tokenChartSymbol = symbol;
        break;
      }
    }
    const questionPatterns = [
      { pattern: /what is (.*)/i, type: "definition" },
      { pattern: /how to (.*)/i, type: "howto" },
      { pattern: /when (.*)/i, "type": "when" },
      { pattern: /where (.*)/i, "type": "where" },
      { pattern: /who is (.*)/i, type: "person" }
    ];
    for (const { pattern, type } of questionPatterns) {
      const match = lowerQuery.match(pattern);
      if (match) {
        showSpecificAnswer = true;
        specificAnswerData = { type, query: match[1] || query, fullQuery: query };
        break;
      }
    }
  }
  function handleSearch() {
    if (!searchQuery.trim()) return;
    isSearching = true;
    resultsLoading = true;
    showSuggestions = false;
    currentPage = 1;
    detectSearchType(searchQuery);
    setTimeout(
      () => {
        isSearching = false;
        hasSearched = true;
      },
      800
    );
    setTimeout(
      () => {
        resultsLoading = false;
      },
      1800
    );
  }
  function handleKeyPress(event) {
    if (event.key === "Enter") {
      handleSearch();
    }
  }
  function handleInput() {
    if (searchQuery.length > 0) {
      suggestions = allSuggestions.filter((s) => s.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 6);
      showSuggestions = suggestions.length > 0;
    } else {
      showSuggestions = false;
    }
  }
  function goToPage(page) {
    currentPage = page;
    document.querySelector("main")?.scrollIntoView({ behavior: "smooth" });
  }
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out.push(`<div class="min-h-screen bg-gradient-to-b from-purple-950 via-purple-900 to-slate-950"><header class="sticky top-0 z-50 border-b border-purple-800/30 bg-purple-950/80 backdrop-blur-xl"><div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"><div class="flex h-16 items-center justify-between"><div class="flex items-center gap-3"><div class="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-purple-500 to-purple-700 shadow-lg shadow-purple-500/25">`);
    Zap($$payload2, { class: "h-5 w-5 text-white" });
    $$payload2.out.push(`<!----></div> <div><h1 class="text-xl font-semibold text-white">Breeze</h1> <p class="text-xs text-purple-300 -mt-0.5">Privacy-First Search</p></div></div> <div class="flex items-center gap-4"><button class="flex items-center gap-2 rounded-full bg-purple-800/50 px-4 py-2 text-sm font-medium text-purple-200 transition-all hover:bg-purple-700/50 hover:text-white">`);
    Shield($$payload2, { class: "h-4 w-4" });
    $$payload2.out.push(`<!----> Privacy Features</button></div></div></div></header> `);
    {
      $$payload2.out.push("<!--[!-->");
    }
    $$payload2.out.push(`<!--]--> <main class="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">`);
    if (!hasSearched) {
      $$payload2.out.push("<!--[-->");
      $$payload2.out.push(`<div class="py-20 text-center"><div class="mx-auto mb-8 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-500 to-purple-700 shadow-2xl shadow-purple-500/25">`);
      Zap($$payload2, { class: "h-10 w-10 text-white" });
      $$payload2.out.push(`<!----></div> <h1 class="mb-4 text-5xl font-bold tracking-tight text-white sm:text-6xl">Search with <span class="bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">confidence</span></h1> <p class="mx-auto mb-12 max-w-2xl text-xl text-purple-200 leading-relaxed">Experience the web without compromise. No tracking, no ads, no data collection. 
					Just pure, private search results.</p></div>`);
    } else {
      $$payload2.out.push("<!--[!-->");
      $$payload2.out.push(`<div class="py-8"></div>`);
    }
    $$payload2.out.push(`<!--]--> <div class="mb-12 search-container"><div class="relative"><div class="flex gap-3"><div class="relative flex-1">`);
    Search($$payload2, {
      class: "absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-purple-400"
    });
    $$payload2.out.push(`<!----> `);
    Input($$payload2, {
      oninput: handleInput,
      onkeypress: handleKeyPress,
      onfocus: handleInput,
      placeholder: "Search privately...",
      class: "h-14 pl-12 pr-16 text-lg border-purple-700/50 bg-purple-900/30 text-white placeholder:text-purple-300 shadow-sm focus:border-purple-500 focus:ring-purple-500/20 focus:ring-4 transition-all duration-200",
      get value() {
        return searchQuery;
      },
      set value($$value) {
        searchQuery = $$value;
        $$settled = false;
      }
    });
    $$payload2.out.push(`<!----> <button${attr_class(`absolute right-4 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg flex items-center justify-center transition-all ${"bg-purple-700/50 text-purple-300 hover:bg-purple-600/50 hover:text-white"}`)}>`);
    {
      $$payload2.out.push("<!--[!-->");
      Mic($$payload2, { class: "h-4 w-4" });
    }
    $$payload2.out.push(`<!--]--></button> `);
    if (showSuggestions) {
      $$payload2.out.push("<!--[-->");
      const each_array = ensure_array_like(suggestions);
      $$payload2.out.push(`<div class="absolute top-full left-0 right-0 mt-2 bg-purple-900/90 border border-purple-700/50 rounded-xl shadow-lg backdrop-blur-sm z-50"><!--[-->`);
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let suggestion = each_array[$$index];
        $$payload2.out.push(`<button class="w-full px-4 py-3 text-left text-purple-200 hover:bg-purple-800/50 hover:text-white first:rounded-t-xl last:rounded-b-xl transition-colors"><div class="flex items-center gap-3">`);
        Search($$payload2, { class: "h-4 w-4 text-purple-400" });
        $$payload2.out.push(`<!----> <span>${escape_html(suggestion)}</span></div></button>`);
      }
      $$payload2.out.push(`<!--]--></div>`);
    } else {
      $$payload2.out.push("<!--[!-->");
    }
    $$payload2.out.push(`<!--]--></div> `);
    Button($$payload2, {
      onclick: handleSearch,
      disabled: isSearching || !searchQuery.trim(),
      class: "h-14 px-8 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-medium shadow-lg shadow-purple-500/25 transition-all duration-200 hover:shadow-xl hover:shadow-purple-500/30",
      children: ($$payload3) => {
        if (isSearching) {
          $$payload3.out.push("<!--[-->");
          $$payload3.out.push(`<div class="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white"></div>`);
        } else {
          $$payload3.out.push("<!--[!-->");
          $$payload3.out.push(`Search`);
        }
        $$payload3.out.push(`<!--]-->`);
      },
      $$slots: { default: true }
    });
    $$payload2.out.push(`<!----></div></div></div> `);
    if (!hasSearched) {
      $$payload2.out.push("<!--[-->");
      $$payload2.out.push(`<div class="grid gap-8 lg:grid-cols-2">`);
      Card($$payload2, {
        class: "border-purple-700/30 bg-purple-900/20 backdrop-blur-sm shadow-sm hover:shadow-md transition-shadow duration-200",
        children: ($$payload3) => {
          Card_content($$payload3, {
            class: "p-6",
            children: ($$payload4) => {
              const each_array_1 = ensure_array_like(trendingSearches);
              $$payload4.out.push(`<div class="mb-6 flex items-center gap-3"><div class="flex h-8 w-8 items-center justify-center rounded-lg bg-orange-500/20">`);
              Trending_up($$payload4, { class: "h-4 w-4 text-orange-400" });
              $$payload4.out.push(`<!----></div> <h3 class="text-lg font-semibold text-white">Trending Searches</h3></div> <div class="space-y-1"><!--[-->`);
              for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
                let search = each_array_1[$$index_1];
                $$payload4.out.push(`<button class="block w-full rounded-lg p-3 text-left text-purple-200 transition-colors duration-150 hover:bg-purple-800/30 hover:text-white">${escape_html(search)}</button>`);
              }
              $$payload4.out.push(`<!--]--></div>`);
            },
            $$slots: { default: true }
          });
        },
        $$slots: { default: true }
      });
      $$payload2.out.push(`<!----> `);
      Card($$payload2, {
        class: "border-purple-700/30 bg-purple-900/20 backdrop-blur-sm shadow-sm hover:shadow-md transition-shadow duration-200",
        children: ($$payload3) => {
          Card_content($$payload3, {
            class: "p-6",
            children: ($$payload4) => {
              const each_array_2 = ensure_array_like(recentSearches);
              $$payload4.out.push(`<div class="mb-6 flex items-center gap-3"><div class="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-500/20">`);
              Clock($$payload4, { class: "h-4 w-4 text-blue-400" });
              $$payload4.out.push(`<!----></div> <h3 class="text-lg font-semibold text-white">Recent Searches</h3></div> <div class="space-y-1"><!--[-->`);
              for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
                let search = each_array_2[$$index_2];
                $$payload4.out.push(`<button class="block w-full rounded-lg p-3 text-left text-purple-200 transition-colors duration-150 hover:bg-purple-800/30 hover:text-white">${escape_html(search)}</button>`);
              }
              $$payload4.out.push(`<!--]--></div>`);
            },
            $$slots: { default: true }
          });
        },
        $$slots: { default: true }
      });
      $$payload2.out.push(`<!----></div> <div class="mt-16 rounded-2xl bg-gradient-to-r from-purple-900/30 to-purple-800/30 backdrop-blur-sm p-8 text-center border border-purple-700/30"><div class="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-purple-500 to-purple-700">`);
      Shield($$payload2, { class: "h-6 w-6 text-white" });
      $$payload2.out.push(`<!----></div> <h3 class="mb-2 text-xl font-semibold text-white">Your Privacy, Guaranteed</h3> <p class="mx-auto max-w-2xl text-purple-200">We don't store your searches, track your activity, or sell your data. 
					Search freely knowing your privacy is protected.</p></div>`);
    } else {
      $$payload2.out.push("<!--[!-->");
    }
    $$payload2.out.push(`<!--]--> `);
    if (hasSearched) {
      $$payload2.out.push("<!--[-->");
      $$payload2.out.push(`<div class="space-y-6"><div class="flex items-center justify-between border-b border-purple-700/30 pb-4"><div><p class="text-purple-200">About <span class="font-medium text-white">847,000</span> results for <span class="font-medium text-white">"${escape_html(searchQuery)}"</span></p> <p class="text-sm text-purple-400 mt-1">Searched privately in 0.31 seconds</p></div> <div class="flex items-center gap-3">`);
      Badge($$payload2, {
        variant: "secondary",
        class: "bg-green-500/20 text-green-400 border-green-500/30",
        children: ($$payload3) => {
          Shield($$payload3, { class: "h-3 w-3 mr-1" });
          $$payload3.out.push(`<!----> Private`);
        },
        $$slots: { default: true }
      });
      $$payload2.out.push(`<!----> <div class="relative export-menu">`);
      Button($$payload2, {
        variant: "outline",
        size: "sm",
        onclick: () => showExportMenu = !showExportMenu,
        class: "border-purple-600 text-purple-300 hover:bg-purple-800/30 hover:text-white",
        children: ($$payload3) => {
          Download($$payload3, { class: "h-4 w-4 mr-2" });
          $$payload3.out.push(`<!----> Export `);
          Chevron_down($$payload3, { class: "h-3 w-3 ml-2" });
          $$payload3.out.push(`<!---->`);
        },
        $$slots: { default: true }
      });
      $$payload2.out.push(`<!----> `);
      if (showExportMenu) {
        $$payload2.out.push("<!--[-->");
        $$payload2.out.push(`<div class="absolute right-0 top-full mt-2 w-48 bg-purple-900/90 border border-purple-700/50 rounded-lg shadow-lg backdrop-blur-sm z-50"><button class="w-full px-4 py-3 text-left text-purple-200 hover:bg-purple-800/50 hover:text-white first:rounded-t-lg transition-colors flex items-center gap-3">`);
        File_text($$payload2, { class: "h-4 w-4 text-red-400" });
        $$payload2.out.push(`<!----> <div><p class="font-medium">Export as PDF</p> <p class="text-xs text-purple-400">Formatted document</p></div></button> <button class="w-full px-4 py-3 text-left text-purple-200 hover:bg-purple-800/50 hover:text-white last:rounded-b-lg transition-colors flex items-center gap-3">`);
        File_spreadsheet($$payload2, { class: "h-4 w-4 text-green-400" });
        $$payload2.out.push(`<!----> <div><p class="font-medium">Export as CSV</p> <p class="text-xs text-purple-400">Spreadsheet data</p></div></button></div>`);
      } else {
        $$payload2.out.push("<!--[!-->");
      }
      $$payload2.out.push(`<!--]--></div></div></div> `);
      if (resultsLoading) {
        $$payload2.out.push("<!--[-->");
        SearchResultSkeleton($$payload2);
        $$payload2.out.push(`<!----> `);
        SearchResultSkeleton($$payload2);
        $$payload2.out.push(`<!----> `);
        SearchResultSkeleton($$payload2);
        $$payload2.out.push(`<!---->`);
      } else {
        $$payload2.out.push("<!--[!-->");
        const each_array_3 = ensure_array_like(mockResults);
        const each_array_4 = ensure_array_like(Array.from({ length: Math.min(7, totalPages) }, (_, i) => {
          const start = Math.max(1, currentPage - 3);
          return start + i;
        }));
        if (showSpecificAnswer) {
          $$payload2.out.push("<!--[-->");
          SpecificAnswer($$payload2, { data: specificAnswerData });
        } else {
          $$payload2.out.push("<!--[!-->");
        }
        $$payload2.out.push(`<!--]--> `);
        if (showCurrencyExchange) {
          $$payload2.out.push("<!--[-->");
          CurrencyExchange($$payload2, { query: searchQuery });
        } else {
          $$payload2.out.push("<!--[!-->");
        }
        $$payload2.out.push(`<!--]--> `);
        if (showWeather) {
          $$payload2.out.push("<!--[-->");
          WeatherWidget($$payload2, { query: searchQuery });
        } else {
          $$payload2.out.push("<!--[!-->");
        }
        $$payload2.out.push(`<!--]--> `);
        if (showSolanaExplorer) {
          $$payload2.out.push("<!--[-->");
          SolanaExplorer($$payload2, { query: solanaQuery, queryType: solanaQueryType });
        } else {
          $$payload2.out.push("<!--[!-->");
        }
        $$payload2.out.push(`<!--]--> `);
        if (showTokenPriceChart) {
          $$payload2.out.push("<!--[-->");
          TokenPriceChart($$payload2, { tokenSymbol: tokenChartSymbol });
        } else {
          $$payload2.out.push("<!--[!-->");
        }
        $$payload2.out.push(`<!--]--> `);
        AISummary($$payload2, { searchQuery });
        $$payload2.out.push(`<!----> <div class="space-y-6"><!--[-->`);
        for (let index = 0, $$length = each_array_3.length; index < $$length; index++) {
          let result = each_array_3[index];
          Card($$payload2, {
            class: "border-purple-700/30 bg-purple-900/20 backdrop-blur-sm shadow-sm hover:shadow-md transition-all duration-200 hover:border-purple-600/50",
            children: ($$payload3) => {
              Card_content($$payload3, {
                class: "p-6",
                children: ($$payload4) => {
                  $$payload4.out.push(`<div class="space-y-3"><div class="flex items-start gap-4">`);
                  SiteLogo($$payload4, { domain: result.domain, hasLogo: result.hasLogo });
                  $$payload4.out.push(`<!----> <div class="flex-1 min-w-0"><div class="flex items-center gap-2 mb-1"><a${attr("href", "https://" + result.url)} class="text-sm text-purple-400 hover:text-purple-300 truncate">${escape_html(result.url)}</a> `);
                  if (result.verified) {
                    $$payload4.out.push("<!--[-->");
                    Badge($$payload4, {
                      variant: "outline",
                      class: "border-emerald-500/30 text-emerald-400 text-xs flex-shrink-0",
                      children: ($$payload5) => {
                        Shield($$payload5, { class: "h-2.5 w-2.5 mr-1" });
                        $$payload5.out.push(`<!----> Verified`);
                      },
                      $$slots: { default: true }
                    });
                  } else {
                    $$payload4.out.push("<!--[!-->");
                  }
                  $$payload4.out.push(`<!--]--> <span class="text-xs text-purple-400 ml-auto flex-shrink-0">${escape_html(result.timestamp)}</span></div> <h3 class="text-xl font-semibold text-white hover:text-purple-400 cursor-pointer transition-colors mb-2">${escape_html(result.title)}</h3> <p class="text-purple-200 leading-relaxed">${escape_html(result.description)}</p></div></div></div>`);
                },
                $$slots: { default: true }
              });
            },
            $$slots: { default: true }
          });
          $$payload2.out.push(`<!----> `);
          if (index === 1) {
            $$payload2.out.push("<!--[-->");
            NewsCarousel($$payload2);
          } else {
            $$payload2.out.push("<!--[!-->");
          }
          $$payload2.out.push(`<!--]-->`);
        }
        $$payload2.out.push(`<!--]--></div> <div class="py-8"><div class="flex items-center justify-center gap-2">`);
        Button($$payload2, {
          variant: "outline",
          size: "sm",
          disabled: currentPage === 1,
          onclick: () => goToPage(currentPage - 1),
          class: "border-purple-600 text-purple-300 hover:bg-purple-800/30 hover:text-white",
          children: ($$payload3) => {
            Chevron_left($$payload3, { class: "h-4 w-4" });
          },
          $$slots: { default: true }
        });
        $$payload2.out.push(`<!----> <!--[-->`);
        for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
          let page = each_array_4[$$index_4];
          if (page <= totalPages) {
            $$payload2.out.push("<!--[-->");
            Button($$payload2, {
              variant: currentPage === page ? "default" : "outline",
              size: "sm",
              onclick: () => goToPage(page),
              class: currentPage === page ? "bg-gradient-to-r from-purple-600 to-purple-700 text-white" : "border-purple-600 text-purple-300 hover:bg-purple-800/30 hover:text-white",
              children: ($$payload3) => {
                $$payload3.out.push(`<!---->${escape_html(page)}`);
              },
              $$slots: { default: true }
            });
          } else {
            $$payload2.out.push("<!--[!-->");
          }
          $$payload2.out.push(`<!--]-->`);
        }
        $$payload2.out.push(`<!--]--> `);
        Button($$payload2, {
          variant: "outline",
          size: "sm",
          disabled: currentPage === totalPages,
          onclick: () => goToPage(currentPage + 1),
          class: "border-purple-600 text-purple-300 hover:bg-purple-800/30 hover:text-white",
          children: ($$payload3) => {
            Chevron_right($$payload3, { class: "h-4 w-4" });
          },
          $$slots: { default: true }
        });
        $$payload2.out.push(`<!----></div> <p class="text-center text-sm text-purple-400 mt-4">Page ${escape_html(currentPage)} of 12 • Showing ${escape_html((currentPage - 1) * resultsPerPage + 1)}-${escape_html(Math.min(currentPage * resultsPerPage, 847e3))} results</p></div>`);
      }
      $$payload2.out.push(`<!--]--></div>`);
    } else {
      $$payload2.out.push("<!--[!-->");
    }
    $$payload2.out.push(`<!--]--></main> <footer class="mt-20 border-t border-purple-800/30 bg-purple-950/30"><div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12"><div class="text-center"><div class="mb-4 flex items-center justify-center gap-2"><div class="flex h-6 w-6 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-purple-700">`);
    Zap($$payload2, { class: "h-3 w-3 text-white" });
    $$payload2.out.push(`<!----></div> <span class="font-semibold text-white">Breeze Search</span></div> <p class="text-purple-200 mb-4">Privacy-first search engine. No tracking, no ads, no compromise.</p> <p class="text-sm text-purple-400">© 2024 Breeze Search. Built with privacy in mind.</p></div></div></footer></div>`);
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
function _page($$payload) {
  App($$payload);
}
export {
  _page as default
};
