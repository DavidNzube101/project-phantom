

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.nH8hN6qu.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/DqfaN5kK.js"];
export const stylesheets = ["_app/immutable/assets/0.BCgnqKkY.css"];
export const fonts = [];
