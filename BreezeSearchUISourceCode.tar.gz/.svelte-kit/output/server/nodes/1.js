

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.C8nwGwoz.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/DcchzcFF.js","_app/immutable/chunks/DqfaN5kK.js","_app/immutable/chunks/C9OSFl0U.js","_app/immutable/chunks/DMAYBwEi.js","_app/immutable/chunks/C8CZytrO.js"];
export const stylesheets = [];
export const fonts = [];
