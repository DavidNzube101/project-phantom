

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.DJWuYR0z.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/DcchzcFF.js","_app/immutable/chunks/DqfaN5kK.js","_app/immutable/chunks/C9OSFl0U.js","_app/immutable/chunks/CJCqZilM.js"];
export const stylesheets = ["_app/immutable/assets/2.BMyg2nj3.css"];
export const fonts = [];
